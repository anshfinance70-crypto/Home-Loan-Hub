import React from 'react';
import { 
  Award, 
  Home, 
  Compass, 
  Building2, 
  MessageSquare, 
  Clock, 
  MapPin, 
  CheckCircle2,
  ShieldCheck
} from 'lucide-react';
import { WHY_CHOOSE_US, BUSINESS_INFO } from '../data/businessData';
import { Language } from '../types';

interface WhyChooseUsProps {
  lang: Language;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ lang }) => {
  const getFeatureIcon = (iconName: string) => {
    switch (iconName) {
      case 'Home': return <Home className="w-5 h-5 text-emerald-600" />;
      case 'Compass': return <Compass className="w-5 h-5 text-emerald-600" />;
      case 'Building2': return <Building2 className="w-5 h-5 text-emerald-600" />;
      case 'MessageSquare': return <MessageSquare className="w-5 h-5 text-emerald-600" />;
      case 'Clock': return <Clock className="w-5 h-5 text-emerald-600" />;
      case 'MapPin': return <MapPin className="w-5 h-5 text-emerald-600" />;
      default: return <Award className="w-5 h-5 text-emerald-600" />;
    }
  };

  return (
    <section id="why-us" className="py-20 bg-slate-50 border-b border-slate-200 text-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
            <Award className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'हमारी विशेषताएं' : 'Key Advantages'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0B192C] tracking-tight">
            {lang === 'hi' ? '⭐ Why Choose Anshfinance?' : '⭐ Why Choose Anshfinance?'}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-normal">
            {lang === 'hi'
              ? 'इंदौर में अपने घर के सपने के लिए Anshfinance को अपना विश्वसनीय सलाहकार क्यों चुनें:'
              : 'Dedicated home loan expertise, verified bank coordination, and responsive local support in Indore.'}
          </p>
        </div>

        {/* 6 Key Advantages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {WHY_CHOOSE_US.map((item) => (
            <div
              key={item.id}
              className="p-6 rounded-2xl bg-white border border-slate-200 hover:border-emerald-500 hover:shadow-md transition-all text-left space-y-3 relative group"
            >
              <div className="flex items-center justify-between">
                <div className="w-11 h-11 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center transition-colors">
                  {getFeatureIcon(item.iconName)}
                </div>
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              </div>

              <h3 className="text-lg font-bold text-[#0B192C] leading-snug">
                {lang === 'hi' ? item.titleHi : item.titleEn}
              </h3>

              <p className="text-sm text-slate-600 font-normal leading-relaxed">
                {lang === 'hi' ? item.descHi : item.descEn}
              </p>
            </div>
          ))}
        </div>

        {/* Trust Endorsement Strip */}
        <div className="p-6 sm:p-8 rounded-2xl bg-[#0B192C] border border-slate-800 text-white flex flex-col md:flex-row items-center justify-between gap-6 text-left shadow-xl">
          <div className="flex items-start gap-4">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h4 className="text-base font-bold text-white">
                {lang === 'hi' ? 'पारदर्शिता व ग्राहक विश्वास हमारी प्राथमिकता' : 'Transparency & Client Trust'}
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 font-normal">
                {lang === 'hi'
                  ? 'हम किसी भी गलत वादे या अवास्तविक गारंटी के बजाय बैंक नीतियों और आपकी वास्तविक वित्तीय क्षमता के अनुसार ही सलाह देते हैं।'
                  : 'We prioritize honest bank matching without deceptive guarantees, safeguarding your time and credit score.'}
              </p>
            </div>
          </div>

          <div className="text-xs text-slate-300 shrink-0 bg-white/10 px-4 py-2.5 rounded-xl border border-white/15">
            <span className="font-bold text-emerald-400">संचालक: {BUSINESS_INFO.owner}</span>
            <br />
            <span>{BUSINESS_INFO.fullAddress}</span>
          </div>
        </div>
      </div>
    </section>
  );
};
