import React, { useState } from 'react';
import { 
  Phone, 
  MessageCircle, 
  Mail, 
  MapPin, 
  Clock, 
  Send, 
  User, 
  Building2, 
  CheckCircle, 
  ExternalLink,
  Navigation
} from 'lucide-react';
import { BUSINESS_INFO } from '../data/businessData';
import { Language, LoanEnquiryForm } from '../types';
import { createWhatsAppUrl, formatIndianCurrency } from '../utils/formatters';

interface ContactSectionProps {
  lang: Language;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ lang }) => {
  const [formData, setFormData] = useState<LoanEnquiryForm>({
    name: '',
    phone: '',
    loanAmount: '₹25 - 40 Lakhs',
    loanPurpose: 'New Home Purchase (नया मकान/फ्लैट)',
    employmentType: 'Salaried (वेतनभोगी)',
    preferredCallTime: 'Morning (सुबह)',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;

    const messageText = `🏠 *New Home Loan Enquiry — Anshfinance*\n\n` +
      `👤 *Name:* ${formData.name}\n` +
      `📞 *Mobile:* ${formData.phone}\n` +
      `💰 *Loan Amount:* ${formData.loanAmount}\n` +
      `🎯 *Purpose:* ${formData.loanPurpose}\n` +
      `💼 *Employment:* ${formData.employmentType}\n` +
      `⏰ *Preferred Time:* ${formData.preferredCallTime}\n` +
      `📝 *Notes/City:* ${formData.message || 'Indore'}`;

    window.open(createWhatsAppUrl(BUSINESS_INFO.whatsapp, messageText), '_blank');
    setSubmitted(true);
  };

  const defaultWaUrl = createWhatsAppUrl(
    BUSINESS_INFO.whatsapp,
    lang === 'hi'
      ? 'नमस्ते दीपक जी, मैं Anshfinance से होम लोन के संबंध में संपर्क करना चाहता हूँ।'
      : 'Hello Deepak ji, I would like to contact Anshfinance regarding a Home Loan inquiry.'
  );

  return (
    <section id="contact" className="py-20 bg-slate-50 border-b border-slate-200 text-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
            <Phone className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'संपर्क सूत्र' : 'Get in Touch'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0B192C] tracking-tight">
            {lang === 'hi' ? '📞 Contact Us (संपर्क करें)' : '📞 Contact Anshfinance'}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-normal">
            {lang === 'hi'
              ? 'दीपक वर्मा जी से सीधे Call या WhatsApp पर संपर्क करें और अपने होम लोन की चर्चा शुरू करें।'
              : 'Direct consultation with Deepak Verma for customized home loan solutions in Indore.'}
          </p>
        </div>

        {/* 2-Column Layout: Contact Card vs Enquiry Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Business Details & Action Buttons */}
          <div className="lg:col-span-5 space-y-6 text-left">
            <div className="p-6 sm:p-8 rounded-2xl bg-[#0B192C] text-white border border-slate-700 shadow-xl space-y-6">
              <div className="space-y-1 border-b border-slate-800 pb-5">
                <div className="text-xs uppercase font-bold tracking-wider text-emerald-400">
                  {BUSINESS_INFO.category}
                </div>
                <h3 className="text-2xl font-bold text-white">{BUSINESS_INFO.name}</h3>
                <p className="text-xs text-slate-300 font-normal">
                  {BUSINESS_INFO.tagline[lang]}
                </p>
              </div>

              {/* Specific Contact Data Points from Prompt */}
              <div className="space-y-4 text-sm">
                {/* Owner */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center shrink-0 text-emerald-400">
                    <User className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">{lang === 'hi' ? 'संचालक (Owner):' : 'Owner / Advisor:'}</div>
                    <div className="font-bold text-white text-base">{BUSINESS_INFO.owner}</div>
                  </div>
                </div>

                {/* Mobile */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center shrink-0 text-emerald-400">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">{lang === 'hi' ? 'मोबाइल (Mobile):' : 'Mobile:'}</div>
                    <a 
                      href={`tel:${BUSINESS_INFO.phone}`} 
                      className="font-bold text-white text-base hover:text-emerald-300 transition-colors"
                    >
                      {BUSINESS_INFO.phone}
                    </a>
                  </div>
                </div>

                {/* WhatsApp */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center shrink-0 text-emerald-400">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">WhatsApp:</div>
                    <a 
                      href={defaultWaUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-bold text-white text-base hover:text-emerald-300 transition-colors"
                    >
                      {BUSINESS_INFO.whatsapp}
                    </a>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center shrink-0 text-emerald-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">{lang === 'hi' ? 'ईमेल (Email):' : 'Email Address:'}</div>
                    <a 
                      href={`mailto:${BUSINESS_INFO.email}`} 
                      className="text-white hover:text-emerald-300 break-all transition-colors text-sm font-medium"
                    >
                      {BUSINESS_INFO.email}
                    </a>
                  </div>
                </div>

                {/* Location */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center shrink-0 text-emerald-400">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">{lang === 'hi' ? 'स्थान (Location):' : 'Office Location:'}</div>
                    <div className="text-slate-200 text-sm font-normal">
                      {BUSINESS_INFO.location}, {BUSINESS_INFO.city}, {BUSINESS_INFO.state}
                    </div>
                    <div className="text-xs text-emerald-400 font-medium mt-0.5">
                      {lang === 'hi' ? 'पास में: गोम्मटगिरि' : 'Nearby: Near Gommatgiri'}
                    </div>
                  </div>
                </div>

                {/* Working Hours */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center shrink-0 text-emerald-400">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">{lang === 'hi' ? 'कार्य समय (Working Hours):' : 'Working Hours:'}</div>
                    <div className="text-white text-sm font-medium">
                      {BUSINESS_INFO.workingHours[lang]}
                    </div>
                  </div>
                </div>
              </div>

              {/* Three Mandatory Buttons from prompt */}
              <div className="pt-2 space-y-2.5">
                <a
                  href={`tel:${BUSINESS_INFO.phone}`}
                  id="contact-call-now-btn"
                  className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md"
                >
                  <Phone className="w-4 h-4 fill-current" />
                  <span>{lang === 'hi' ? '📞 Call Now (9826686170)' : '📞 Call Now (9826686170)'}</span>
                </a>

                <a
                  href={defaultWaUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  id="contact-whatsapp-now-btn"
                  className="w-full py-3.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#1EBE5D] text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>{lang === 'hi' ? '💬 WhatsApp Now (9826686170)' : '💬 WhatsApp Now (9826686170)'}</span>
                </a>

                <a
                  href={BUSINESS_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  id="contact-get-directions-btn"
                  className="w-full py-3.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all"
                >
                  <Navigation className="w-4 h-4 text-emerald-400" />
                  <span>{lang === 'hi' ? '📍 Get Directions (Google Maps)' : '📍 Get Directions (Google Maps)'}</span>
                </a>
              </div>
            </div>

            {/* Local Maps Visual Representation */}
            <div className="p-5 rounded-xl bg-white border border-slate-200 text-left space-y-2 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <span>Indore Office Location</span>
                </span>
                <a
                  href={BUSINESS_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-bold text-emerald-600 hover:underline flex items-center gap-1"
                >
                  <span>Open in Maps</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <p className="text-xs text-slate-600 font-normal">
                265-B, Arihant Nagar, Near Gommatgiri, Indore, Madhya Pradesh. Easily accessible from Airport Road and Super Corridor.
              </p>
            </div>
          </div>

          {/* Right Column: Home Loan Enquiry Form */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 shadow-xl text-left">
            <div className="space-y-2 mb-6">
              <h3 className="text-2xl font-bold text-[#0B192C]">
                {lang === 'hi' ? '📝 होम लोन पूछताछ फॉर्म' : '📝 Home Loan Enquiry Form'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 font-normal">
                {lang === 'hi'
                  ? 'अपनी बुनियादी जानकारी भरें। दीपक वर्मा जी आपकी पात्रता अनुसार सही बैंक विकल्पों के साथ संपर्क करेंगे।'
                  : 'Fill in your basic information. Deepak Verma will coordinate suitable loan alternatives.'}
              </p>
            </div>

            {submitted ? (
              <div className="p-8 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                  <CheckCircle className="w-7 h-7" />
                </div>
                <h4 className="text-xl font-bold text-[#0B192C]">
                  {lang === 'hi' ? 'धन्यवाद! आपकी पूछताछ प्राप्त हुई।' : 'Thank You! Enquiry Received.'}
                </h4>
                <p className="text-sm text-slate-600 max-w-md mx-auto font-normal">
                  {lang === 'hi'
                    ? 'दीपक वर्मा (Anshfinance) द्वारा जल्द ही आपसे 9826686170 से संपर्क किया जाएगा। आप चाहें तो अभी सीधे WhatsApp पर भी जुड़ सकते हैं।'
                    : 'Deepak Verma will reach out to you shortly. You may also connect directly on WhatsApp.'}
                </p>
                <div className="pt-2 flex flex-wrap justify-center gap-3">
                  <button
                    onClick={() => setSubmitted(false)}
                    className="px-4 py-2.5 rounded-xl bg-white border border-slate-300 text-xs font-bold uppercase tracking-wider text-slate-700 hover:bg-slate-50 cursor-pointer shadow-xs"
                  >
                    {lang === 'hi' ? 'नया फॉर्म भरें' : 'Submit Another Enquiry'}
                  </button>
                  <a
                    href={`tel:${BUSINESS_INFO.phone}`}
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-xs"
                  >
                    <Phone className="w-3.5 h-3.5 fill-current" />
                    <span>Call 9826686170</span>
                  </a>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {lang === 'hi' ? 'आपका नाम (Full Name) *' : 'Your Full Name *'}
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="उदा. राहुल शर्मा"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                    />
                  </div>

                  {/* Phone */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {lang === 'hi' ? 'मोबाइल नंबर (WhatsApp No.) *' : 'Mobile / WhatsApp Number *'}
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="उदा. 98266XXXXX"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Loan Amount */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {lang === 'hi' ? 'अपेक्षित लोन राशि (Required Amount)' : 'Required Loan Amount'}
                    </label>
                    <select
                      value={formData.loanAmount}
                      onChange={(e) => setFormData({ ...formData, loanAmount: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-hidden focus:border-emerald-600 focus:bg-white"
                    >
                      <option>₹10 - 20 Lakhs</option>
                      <option>₹20 - 35 Lakhs</option>
                      <option>₹35 - 50 Lakhs</option>
                      <option>₹50 - 75 Lakhs</option>
                      <option>₹75 Lakhs - ₹1.5 Crore</option>
                      <option>₹1.5 Crore+</option>
                    </select>
                  </div>

                  {/* Purpose */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {lang === 'hi' ? 'लोन का उद्देश्य (Purpose)' : 'Loan Purpose'}
                    </label>
                    <select
                      value={formData.loanPurpose}
                      onChange={(e) => setFormData({ ...formData, loanPurpose: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-hidden focus:border-emerald-600 focus:bg-white"
                    >
                      <option>New Home Purchase (नया मकान/फ्लैट)</option>
                      <option>Construction on Plot (प्लॉट पर मकान निर्माण)</option>
                      <option>Plot + Construction (प्लॉट एवं निर्माण)</option>
                      <option>Home Renovation / Extension (विस्तार/सुधार)</option>
                      <option>Balance Transfer & Top-Up (लोन ट्रांसफर)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Employment */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {lang === 'hi' ? 'रोजगार का प्रकार (Employment)' : 'Employment Type'}
                    </label>
                    <select
                      value={formData.employmentType}
                      onChange={(e) => setFormData({ ...formData, employmentType: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-hidden focus:border-emerald-600 focus:bg-white"
                    >
                      <option>Salaried (प्राइवेट या सरकारी नौकरी)</option>
                      <option>Self-Employed Professional (डॉक्टर, सीए, आदि)</option>
                      <option>Business / Trader (व्यापार / दुकान / उद्यम)</option>
                      <option>Other / Freelance (अन्य)</option>
                    </select>
                  </div>

                  {/* Calling Time */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {lang === 'hi' ? 'बातचीत का उपयुक्त समय' : 'Preferred Discussion Time'}
                    </label>
                    <select
                      value={formData.preferredCallTime}
                      onChange={(e) => setFormData({ ...formData, preferredCallTime: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-hidden focus:border-emerald-600 focus:bg-white"
                    >
                      <option>Morning (सुबह 7:00 - 11:00 AM)</option>
                      <option>Afternoon (दोपहर 11:00 AM - 4:00 PM)</option>
                      <option>Evening (शाम 4:00 - 8:00 PM)</option>
                      <option>Night (रात 8:00 - 10:00 PM)</option>
                      <option>Anytime (कभी भी)</option>
                    </select>
                  </div>
                </div>

                {/* Message / Location */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    {lang === 'hi' ? 'प्रॉपर्टी लोकेशन / कोई विशेष प्रश्न (वैकल्पिक)' : 'Property Location / Special Query'}
                  </label>
                  <textarea
                    rows={3}
                    placeholder="उदा. इंदौर में विजय नगर/सुपर कॉरिडोर में 2BHK फ्लैट हेतु..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-2 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                  />
                </div>

                <button
                  type="submit"
                  id="submit-enquiry-form-btn"
                  className="w-full py-3.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <Send className="w-4 h-4 fill-current" />
                  <span>{lang === 'hi' ? 'WhatsApp पर पूछताछ भेजें (Send Enquiry)' : 'Send Enquiry via WhatsApp'}</span>
                </button>

                <p className="text-[11px] text-slate-500 font-medium text-center">
                  {lang === 'hi'
                    ? '🔒 आपकी जानकारी सुरक्षित रखी जाती है और केवल लोन प्रक्रिया हेतु उपयोग की जाती है।'
                    : '🔒 Your data is kept strictly confidential for financial consultation.'}
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
