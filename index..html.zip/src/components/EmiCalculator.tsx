import React, { useState, useMemo } from 'react';
import { 
  Calculator, 
  IndianRupee, 
  Calendar, 
  Percent, 
  MessageCircle, 
  HelpCircle, 
  Sparkles,
  ArrowRight,
  TrendingDown
} from 'lucide-react';
import { calculateEmi, formatIndianCurrency, createWhatsAppUrl } from '../utils/formatters';
import { BUSINESS_INFO } from '../data/businessData';
import { Language } from '../types';

interface EmiCalculatorProps {
  lang: Language;
  onOpenEnquiry: () => void;
}

export const EmiCalculator: React.FC<EmiCalculatorProps> = ({ lang, onOpenEnquiry }) => {
  const [loanAmount, setLoanAmount] = useState<number>(3000000); // 30 Lakhs default
  const [interestRate, setInterestRate] = useState<number>(8.5); // 8.5% p.a.
  const [tenureYears, setTenureYears] = useState<number>(20); // 20 years

  const calculation = useMemo(() => {
    return calculateEmi(loanAmount, interestRate, tenureYears);
  }, [loanAmount, interestRate, tenureYears]);

  const presetAmounts = [
    { label: '₹15L', val: 1500000 },
    { label: '₹25L', val: 2500000 },
    { label: '₹35L', val: 3500000 },
    { label: '₹50L', val: 5000000 },
    { label: '₹75L', val: 7500000 },
    { label: '₹1 Cr', val: 10000000 },
  ];

  const handleWhatsAppEnquiry = () => {
    const message = lang === 'hi'
      ? `नमस्ते दीपक जी (Anshfinance), मैंने आपकी वेबसाइट पर होम लोन कैलकुलेट किया है:\n\n• लोन राशि: ${formatIndianCurrency(loanAmount)}\n• ब्याज दर: ${interestRate}%\n• अवधि: ${tenureYears} वर्ष\n• अनुमानित मासिक EMI: ${formatIndianCurrency(calculation.monthlyEmi)}\n\nकृपया मेरी पात्रता और संबंधित बैंकों के विकल्पों पर मार्गदर्शन करें।`
      : `Hello Deepak ji (Anshfinance), I used your website EMI calculator:\n\n• Loan Amount: ${formatIndianCurrency(loanAmount)}\n• Interest Rate: ${interestRate}%\n• Tenure: ${tenureYears} Years\n• Estimated Monthly EMI: ${formatIndianCurrency(calculation.monthlyEmi)}\n\nPlease advise on suitable bank options.`;

    window.open(createWhatsAppUrl(BUSINESS_INFO.whatsapp, message), '_blank');
  };

  return (
    <section id="calculator" className="py-20 bg-white border-b border-slate-200 text-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
            <Calculator className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'मासिक किश्त का अनुमान' : 'Smart EMI Estimator'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0B192C] tracking-tight">
            {lang === 'hi' ? '🏠 होम लोन EMI कैलकुलेटर' : '🏠 Home Loan EMI Calculator'}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-normal">
            {lang === 'hi'
              ? 'अपनी लोन राशि, ब्याज दर और अवधि चुनकर तुरंत मासिक EMI व कुल ब्याज का अनुमान लगाएं।'
              : 'Calculate your exact monthly installments, interest burden, and principal ratio in seconds.'}
          </p>
        </div>

        {/* Calculator Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Sliders & Controls */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl bg-slate-50 border border-slate-200 shadow-sm space-y-8 text-left">
            {/* 1. Loan Amount */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <label className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <IndianRupee className="w-4 h-4 text-emerald-600" />
                  <span>{lang === 'hi' ? 'होम लोन राशि (Loan Amount)' : 'Home Loan Amount'}</span>
                </label>
                <div className="text-lg sm:text-xl font-bold text-emerald-700 bg-emerald-50 px-3.5 py-1 rounded-lg border border-emerald-200">
                  {formatIndianCurrency(loanAmount)}
                </div>
              </div>

              <input
                type="range"
                min={500000}
                max={15000000}
                step={50000}
                value={loanAmount}
                onChange={(e) => setLoanAmount(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />

              {/* Quick Presets */}
              <div className="flex flex-wrap gap-2 pt-1">
                {presetAmounts.map((p) => (
                  <button
                    key={p.val}
                    type="button"
                    onClick={() => setLoanAmount(p.val)}
                    className={`px-3 py-1 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                      loanAmount === p.val
                        ? 'bg-emerald-600 text-white font-bold border-emerald-600 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-500 hover:text-emerald-600 shadow-2xs'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Interest Rate */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <label className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <Percent className="w-4 h-4 text-emerald-600" />
                  <span>{lang === 'hi' ? 'वार्षिक ब्याज दर (Interest Rate % p.a.)' : 'Interest Rate (% p.a.)'}</span>
                </label>
                <div className="text-lg sm:text-xl font-bold text-emerald-700 bg-emerald-50 px-3.5 py-1 rounded-lg border border-emerald-200">
                  {interestRate.toFixed(2)}%
                </div>
              </div>

              <input
                type="range"
                min={7.0}
                max={14.0}
                step={0.05}
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />

              <div className="flex justify-between text-[11px] text-slate-500 font-medium">
                <span>7.0% (Subsidized/Prime)</span>
                <span className="text-emerald-700 font-semibold">Standard Bank Range: ~8.40% - 9.25%</span>
                <span>14.0%</span>
              </div>
            </div>

            {/* 3. Loan Tenure */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <label className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-emerald-600" />
                  <span>{lang === 'hi' ? 'ऋण अवधि (Tenure)' : 'Loan Tenure (Years)'}</span>
                </label>
                <div className="text-lg sm:text-xl font-bold text-emerald-700 bg-emerald-50 px-3.5 py-1 rounded-lg border border-emerald-200">
                  {tenureYears} {lang === 'hi' ? 'वर्ष' : 'Years'} ({tenureYears * 12} माह)
                </div>
              </div>

              <input
                type="range"
                min={1}
                max={30}
                step={1}
                value={tenureYears}
                onChange={(e) => setTenureYears(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />

              <div className="flex gap-2">
                {[10, 15, 20, 25, 30].map((yr) => (
                  <button
                    key={yr}
                    type="button"
                    onClick={() => setTenureYears(yr)}
                    className={`px-3 py-1 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                      tenureYears === yr
                        ? 'bg-emerald-600 text-white font-bold border-emerald-600 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-500 hover:text-emerald-600 shadow-2xs'
                    }`}
                  >
                    {yr} {lang === 'hi' ? 'वर्ष' : 'Yrs'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Results & Direct Action Card */}
          <div className="lg:col-span-5 p-6 sm:p-8 rounded-2xl bg-[#0B192C] border border-slate-800 text-white shadow-xl space-y-6 text-left">
            <div className="space-y-1">
              <div className="text-xs uppercase font-bold tracking-wider text-emerald-400">
                {lang === 'hi' ? 'अनुमानित मासिक किस्त' : 'Estimated Monthly Installment'}
              </div>
              <div className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
                {formatIndianCurrency(calculation.monthlyEmi)}
                <span className="text-sm font-normal text-slate-400 ml-1">/ माह</span>
              </div>
            </div>

            {/* Ratio Breakdown Bar */}
            <div className="space-y-2 pt-2">
              <div className="flex justify-between text-xs text-slate-300 font-medium">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
                  {lang === 'hi' ? 'मूलधन (Principal)' : 'Principal'} ({calculation.principalPercent}%)
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-500 inline-block" />
                  {lang === 'hi' ? 'ब्याज (Total Interest)' : 'Interest'} ({calculation.interestPercent}%)
                </span>
              </div>

              <div className="w-full h-2.5 bg-slate-700 rounded-full overflow-hidden flex">
                <div 
                  className="bg-emerald-400 h-full transition-all duration-300"
                  style={{ width: `${calculation.principalPercent}%` }}
                />
                <div 
                  className="bg-slate-500 h-full transition-all duration-300"
                  style={{ width: `${calculation.interestPercent}%` }}
                />
              </div>
            </div>

            {/* Financial Details Table */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2.5 text-xs sm:text-sm">
              <div className="flex justify-between items-center text-slate-300">
                <span>{lang === 'hi' ? 'लोन राशि (Principal):' : 'Loan Principal:'}</span>
                <span className="font-bold text-white">{formatIndianCurrency(calculation.principalAmount)}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>{lang === 'hi' ? 'कुल देय ब्याज (Total Interest):' : 'Total Interest Payable:'}</span>
                <span className="font-bold text-emerald-400">{formatIndianCurrency(calculation.totalInterest)}</span>
              </div>
              <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-sm font-bold">
                <span className="text-white">{lang === 'hi' ? 'कुल भुगतान (Total Payable):' : 'Total Amount Payable:'}</span>
                <span className="text-emerald-400 text-base">{formatIndianCurrency(calculation.totalPayment)}</span>
              </div>
            </div>

            {/* CTA Buttons based on this calculation */}
            <div className="space-y-2.5 pt-2">
              <button
                type="button"
                onClick={handleWhatsAppEnquiry}
                className="w-full py-3.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#1EBE5D] text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>{lang === 'hi' ? 'इस EMI पर WhatsApp पर बात करें' : 'Discuss this EMI on WhatsApp'}</span>
              </button>

              <button
                type="button"
                onClick={onOpenEnquiry}
                className="w-full py-3.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-white border border-white/20 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>{lang === 'hi' ? 'अनुकूलित लोन सलाह प्राप्त करें' : 'Get Tailored Loan Advice'}</span>
                <ArrowRight className="w-4 h-4 text-emerald-400" />
              </button>
            </div>

            <p className="text-[11px] text-slate-400 font-normal leading-relaxed">
              {lang === 'hi'
                ? '* यह गणना केवल सांकेतिक अनुमान है। वास्तविक ईएमआई बैंक की प्रचलित दरों व नीतियों पर निर्भर करेगी।'
                : '* Values are indicative estimates. Actual bank interest and EMI will depend on lender sanctions.'}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
