import React, { useState } from 'react';
import { HelpCircle, ChevronDown } from 'lucide-react';
import { FAQ_ITEMS } from '../data/businessData';
import { Language } from '../types';

interface FaqSectionProps {
  lang: Language;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ lang }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20 bg-white border-b border-slate-200 text-slate-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
            <HelpCircle className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'अक्सर पूछे जाने वाले सवाल' : 'FAQs'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0B192C] tracking-tight">
            {lang === 'hi' ? 'होम लोन से जुड़े सामान्य प्रश्न' : 'Frequently Asked Questions'}
          </h2>
          <p className="text-base text-slate-600 font-normal">
            {lang === 'hi'
              ? 'Anshfinance की कार्यप्रणाली और होम लोन से जुड़े महत्वपूर्ण प्रश्नों के उत्तर'
              : 'Clear answers regarding our advisory process, bank evaluation, and timings.'}
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-4 text-left">
          {FAQ_ITEMS.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className={`rounded-xl border transition-all overflow-hidden ${
                  isOpen
                    ? 'bg-emerald-50/50 border-emerald-400 shadow-xs'
                    : 'bg-slate-50 border-slate-200 hover:border-slate-300 hover:bg-white'
                }`}
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full p-5 flex items-center justify-between gap-4 text-left font-bold text-[#0B192C] hover:text-emerald-700 transition-colors focus:outline-hidden cursor-pointer"
                >
                  <span className="text-base sm:text-lg">
                    {lang === 'hi' ? faq.qHi : faq.qEn}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-emerald-600' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 text-sm sm:text-base text-slate-600 font-normal leading-relaxed border-t border-emerald-100 pt-3">
                    {lang === 'hi' ? faq.aHi : faq.aEn}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
