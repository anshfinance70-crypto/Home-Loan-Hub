import React from 'react';
import { 
  Home, 
  HelpCircle, 
  Search, 
  Compass, 
  FileCheck2, 
  Building2, 
  ArrowRightCircle, 
  AlertCircle, 
  Key, 
  Hammer, 
  Layers, 
  Paintbrush, 
  ArrowLeftRight,
  ShieldAlert,
  Phone,
  MessageCircle
} from 'lucide-react';
import { 
  BUSINESS_INFO, 
  BANK_NETWORK_DISCLAIMER, 
  REGULATORY_NOTE, 
  LOAN_TYPES, 
  PROMINENT_BANKS 
} from '../data/businessData';
import { Language } from '../types';
import { createWhatsAppUrl } from '../utils/formatters';

interface ServicesSectionProps {
  lang: Language;
  onOpenEnquiry: () => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ lang, onOpenEnquiry }) => {
  const supportPoints = [
    {
      titleHi: 'Home Loan Enquiry',
      titleEn: 'Home Loan Enquiry',
      descHi: 'आपकी होम लोन आवश्यकता, बजट और पात्रता की प्रारंभिक जांच व चर्चा।',
      descEn: 'Initial review and consultation on your financing requirements and preliminary eligibility.',
      icon: Search,
    },
    {
      titleHi: 'Loan Options समझने में',
      titleEn: 'Comparing Loan Options',
      descHi: 'विभिन्न लेंडर्स की ब्याज दरें, प्रोसेसिंग फीस और नियम-शर्तों की निष्पक्ष तुलना।',
      descEn: 'Clear, unbiased breakdown of interest rates, tenures, and terms across lenders.',
      icon: Compass,
    },
    {
      titleHi: 'Application Process Guidance',
      titleEn: 'Application Process Guidance',
      descHi: 'लोन आवेदन फॉर्म भरने और बैंक मानकों अनुसार फाइल व्यवस्थित करने में मार्गदर्शन।',
      descEn: 'Expert guidance on filling application forms and organizing supporting documents.',
      icon: FileCheck2,
    },
    {
      titleHi: 'Required Documents की जानकारी',
      titleEn: 'Document Checklist & Prep',
      descHi: 'आय, पहचान, बैंक विवरण और प्रॉपर्टी से जुड़े आवश्यक कागजातों की संपूर्ण सूची।',
      descEn: 'Complete clarity on required KYC, financial, and legal property paperwork.',
      icon: HelpCircle,
    },
    {
      titleHi: 'Bank/NBFC Process Coordination',
      titleEn: 'Bank / NBFC Coordination',
      descHi: 'बैंक अधिकारियों, वैल्युअर और लीगल वकीलों के साथ समन्वय स्थापित करना।',
      descEn: 'Active follow-up with bank officers, field verifiers, and legal advocates.',
      icon: Building2,
    },
    {
      titleHi: 'Loan Application की आगे की प्रक्रिया',
      titleEn: 'Sanction & Post-Sanction Help',
      descHi: 'स्वीकृति पत्र (Sanction Letter) प्राप्त होने और डिस्बर्समेंट तक निरंतर सहायता।',
      descEn: 'Continuous support from approval letter issuance through final loan disbursement.',
      icon: ArrowRightCircle,
    },
  ];

  const getLoanTypeIcon = (icon: string) => {
    switch (icon) {
      case 'Key': return <Key className="w-5 h-5 text-emerald-600" />;
      case 'Hammer': return <Hammer className="w-5 h-5 text-emerald-600" />;
      case 'Layers': return <Layers className="w-5 h-5 text-emerald-600" />;
      case 'Paintbrush': return <Paintbrush className="w-5 h-5 text-emerald-600" />;
      case 'ArrowLeftRight': return <ArrowLeftRight className="w-5 h-5 text-emerald-600" />;
      default: return <Home className="w-5 h-5 text-emerald-600" />;
    }
  };

  return (
    <section id="services" className="py-20 bg-slate-50 border-b border-slate-200 text-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
            <Home className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'हमारी मुख्य सेवा' : 'Our Main Service'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0B192C] tracking-tight">
            {lang === 'hi' ? '🏠 Home Loan (होम लोन सेवा)' : '🏠 Comprehensive Home Loan Services'}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-normal">
            {lang === 'hi'
              ? 'Anshfinance ग्राहकों को उनके घर के सपने के लिए Home Loan की प्रक्रिया में उचित सहायता प्रदान करता है।'
              : 'Helping home buyers and builders in Indore navigate the entire loan journey with clarity.'}
          </p>
        </div>

        {/* 6 Key Areas Anshfinance Assists With (Prompt Specific) */}
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-200 pb-3">
            <h3 className="text-xl font-bold text-[#0B192C]">
              {lang === 'hi' ? 'हम किस प्रकार सहायता करते हैं:' : 'How We Assist Home Loan Applicants:'}
            </h3>
            <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">
              {lang === 'hi' ? 'कदम-दर-कदम व्यक्तिगत मार्गदर्शन' : 'Step-by-step personalized assistance'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {supportPoints.map((point, index) => {
              const IconComp = point.icon;
              return (
                <div 
                  key={index}
                  className="p-6 rounded-xl bg-white border border-slate-200 hover:border-emerald-400 hover:shadow-md transition-all text-left space-y-3"
                >
                  <div className="w-11 h-11 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
                    <IconComp className="w-5 h-5" />
                  </div>
                  <h4 className="text-lg font-bold text-[#0B192C]">
                    {lang === 'hi' ? point.titleHi : point.titleEn}
                  </h4>
                  <p className="text-sm text-slate-600 font-normal leading-relaxed">
                    {lang === 'hi' ? point.descHi : point.descEn}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Home Loan Categories (Cards) */}
        <div className="space-y-6 pt-4">
          <div className="text-left space-y-1">
            <h3 className="text-xl font-bold text-[#0B192C]">
              {lang === 'hi' ? 'उपलब्ध होम लोन श्रेणियां (Loan Types)' : 'Home Loan Options We Cover'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 font-normal">
              {lang === 'hi' 
                ? 'आपकी जरूरत चाहे नया मकान हो, प्लॉट पर निर्माण या पुराने लोन की री-फाइनेंसिंग'
                : 'Whether buying, building, renovating, or transferring an existing home loan.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {LOAN_TYPES.map((loan) => (
              <div 
                key={loan.id}
                className="p-6 rounded-xl bg-white border border-slate-200 hover:border-emerald-400 hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3 text-left">
                  <div className="flex items-center justify-between">
                    <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-100">
                      {getLoanTypeIcon(loan.icon)}
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100/70 text-emerald-800 border border-emerald-200">
                      {lang === 'hi' ? loan.tagHi : loan.tagEn}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-[#0B192C]">
                    {lang === 'hi' ? loan.titleHi : loan.titleEn}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-600 font-normal leading-relaxed">
                    {lang === 'hi' ? loan.descHi : loan.descEn}
                  </p>
                </div>

                <button
                  onClick={onOpenEnquiry}
                  className="w-full py-2.5 px-3 text-xs font-bold uppercase tracking-wider rounded-lg border border-slate-200 bg-slate-50 hover:bg-emerald-600 hover:text-white hover:border-emerald-600 text-slate-700 flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs"
                >
                  <span>{lang === 'hi' ? 'इस लोन के लिए पूछताछ करें' : 'Enquire for this Loan'}</span>
                  <ArrowRightCircle className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Bank Network Section (Crucial requirement from prompt) */}
        <div className="p-8 rounded-2xl bg-[#0B192C] border border-slate-700 text-white shadow-xl space-y-6 text-left">
          <div className="max-w-3xl space-y-3">
            <div className="inline-block px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-bold uppercase tracking-wider">
              {lang === 'hi' ? 'बैंक एवं संस्थान नेटवर्क' : 'Lender Network'}
            </div>
            <h3 className="text-2xl sm:text-3xl font-bold text-white">
              {BANK_NETWORK_DISCLAIMER[lang]}
            </h3>
            <p className="text-sm text-slate-300 font-normal leading-relaxed">
              {lang === 'hi'
                ? 'Anshfinance प्रमुख सार्वजनिक, निजी बैंकों एवं प्रतिष्ठित हाउसिंग फाइनेंस कंपनियों (NBFCs) के साथ काम करता है, ताकि आपकी आय व प्रोफाइल अनुसार सही ब्याज दर और अधिकतम लोन पात्रता मिल सके।'
                : 'We coordinate with major nationalized banks, leading private sector lenders, and specialized housing NBFCs to match your profile with optimal loan terms.'}
            </p>
          </div>

          {/* Prominent Lenders Pill Grid */}
          <div className="flex flex-wrap gap-2.5 pt-2">
            {PROMINENT_BANKS.map((bank, i) => (
              <div 
                key={i}
                className="px-3.5 py-2 rounded-lg bg-white/10 border border-white/15 text-xs text-white/90 flex items-center gap-2 hover:border-emerald-400/50 transition-colors"
              >
                <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-semibold text-white">{bank.name}</span>
                <span className="text-[10px] text-slate-400">({bank.tag})</span>
              </div>
            ))}
          </div>

          {/* Prompt Mandated Regulatory Note */}
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-400/30 text-amber-100 text-xs sm:text-sm flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed font-normal">
              <span className="font-bold text-amber-300 uppercase tracking-wider font-mono text-xs">
                {lang === 'hi' ? 'महत्वपूर्ण सूचना (Important Note): ' : 'Important Notice: '}
              </span>
              <span>{REGULATORY_NOTE[lang]}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
