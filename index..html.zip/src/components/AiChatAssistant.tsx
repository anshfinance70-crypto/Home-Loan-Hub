import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  X, 
  Sparkles, 
  RotateCcw, 
  Phone, 
  MessageCircle, 
  ChevronDown, 
  Copy, 
  Check, 
  ArrowUpRight,
  ShieldAlert,
  Building2,
  FileQuestion
} from 'lucide-react';
import { Language, ChatMessage } from '../types';
import { BUSINESS_INFO } from '../data/businessData';
import { createWhatsAppUrl } from '../utils/formatters';

interface AiChatAssistantProps {
  lang: Language;
  isOpen: boolean;
  onClose: () => void;
  onOpen: () => void;
  initialQuery?: string;
}

const INITIAL_SUGGESTIONS_HI = [
  '📋 होम लोन के लिए कौन-कौन से आवश्यक दस्तावेज चाहिए?',
  '💰 वर्तमान में ब्याज दरें (Interest Rates) क्या चल रही हैं?',
  '🏗️ क्या खाली प्लॉट पर निर्माण के लिए लोन मिल सकता है?',
  '📊 CIBIL स्कोर 700 से कम हो तो क्या लोन संभव है?',
  '🔄 पुराने महंगे होम लोन का बैलेंस ट्रांसफर कैसे कराएं?',
  '📞 दीपक जी (Anshfinance) से सीधे संपर्क कैसे करें?'
];

const INITIAL_SUGGESTIONS_EN = [
  '📋 What are the mandatory documents for home loan?',
  '💰 What are the current interest rates across major banks?',
  '🏗️ How to apply for a plot purchase + home construction loan?',
  '📊 Can I get a home loan with a CIBIL score below 700?',
  '🔄 How does home loan balance transfer save money?',
  '📞 How can I reach Deepak Verma directly in Indore?'
];

export const AiChatAssistant: React.FC<AiChatAssistantProps> = ({
  lang,
  isOpen,
  onClose,
  onOpen,
  initialQuery
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isMinimized, setIsMinimized] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Initialize initial welcoming message
  useEffect(() => {
    if (messages.length === 0) {
      const welcomeMessage: ChatMessage = {
        id: 'welcome-msg',
        role: 'model',
        text: lang === 'hi'
          ? `नमस्ते! मैं **Anshfinance AI Sahayak** हूँ — इंदौर में होम लोन संबंधी सभी सवालों का आपका डिजिटल मार्गदर्शक।

आप मुझसे होम लोन के प्रकार, पात्रता (Eligibility), ब्याज दरें, आवश्यक दस्तावेज और बैंक तुलना के बारे में कुछ भी पूछ सकते हैं।

नीचे दिए गए किसी भी सुझाव पर क्लिक करें या अपना प्रश्न टाइप करें:`
          : `Hello! I am **Anshfinance AI Sahayak** — your dedicated digital advisor for home loan information in Indore.

You can ask me about loan types, eligibility, current interest rates, mandatory documentation, and bank comparison.

Click any suggestion below or type your question:`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages([welcomeMessage]);
    }
  }, [lang]);

  // Handle initial query triggered from outside (e.g. from Hero or Services section)
  useEffect(() => {
    if (initialQuery && initialQuery.trim()) {
      handleSend(initialQuery);
    }
  }, [initialQuery]);

  // Scroll to bottom when messages update
  useEffect(() => {
    if (isOpen && !isMinimized) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading, isOpen, isMinimized]);

  // Focus input when opened
  useEffect(() => {
    if (isOpen && !isMinimized) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 300);
    }
  }, [isOpen, isMinimized]);

  const handleSend = async (userText?: string) => {
    const textToSend = (userText || input).trim();
    if (!textToSend || isLoading) return;

    setHasInteracted(true);
    setInput('');

    const userMessage: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setIsLoading(true);

    try {
      // Send conversation to backend /api/chat
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map(m => ({ role: m.role, text: m.text })),
          lang
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      const replyText = data.reply || (lang === 'hi' 
        ? 'क्षमा करें, उत्तर प्राप्त करने में समस्या हुई। कृपया पुनः प्रयास करें या सीधे 9826686170 पर संपर्क करें।' 
        : 'Apologies, could not fetch reply. Please retry or contact Deepak Verma at 9826686170.');

      const botMessage: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'model',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (err) {
      console.error('Error fetching AI chat reply:', err);
      const errorMessage: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        text: lang === 'hi'
          ? `⚠️ इंटरनेट या सर्वर में व्यवधान के कारण सीधा संपर्क नहीं हो पाया।

आप अपनी फाइल व होम लोन की विस्तृत जानकारी के लिए सीधे **दीपक वर्मा (Anshfinance)** से **9826686170** पर कॉल या WhatsApp कर सकते हैं।`
          : `⚠️ There was a temporary connection issue.

For immediate assistance, please call or WhatsApp **Deepak Verma (Anshfinance) at +91 9826686170**.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetChat = () => {
    const welcomeMessage: ChatMessage = {
      id: `welcome-${Date.now()}`,
      role: 'model',
      text: lang === 'hi'
        ? `नमस्ते! बातचीत रीसेट कर दी गई है। आप होम लोन, पात्रता, ब्याज दर या दस्तावेजों से जुड़ा कोई भी नया प्रश्न पूछ सकते हैं।`
        : `Hello! Conversation reset. Feel free to ask any question regarding home loans, interest rates, documentation, or bank matching.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages([welcomeMessage]);
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Pre-fill WhatsApp with question/chat context
  const getWhatsAppChatUrl = () => {
    const lastUserQuery = messages.filter(m => m.role === 'user').slice(-1)[0]?.text || '';
    const text = lang === 'hi'
      ? `नमस्ते दीपक जी (Anshfinance), मैंने वेबसाइट AI चैट पर होम लोन के संबंध में यह प्रश्न पूछा था:\n"${lastUserQuery}"\n\nकृपया इस पर मार्गदर्शन करें।`
      : `Hello Deepak ji (Anshfinance), I was inquiring via the AI Assistant about:\n"${lastUserQuery}"\n\nPlease guide me further.`;
    return createWhatsAppUrl(BUSINESS_INFO.whatsapp, text);
  };

  const suggestions = lang === 'hi' ? INITIAL_SUGGESTIONS_HI : INITIAL_SUGGESTIONS_EN;

  // Format bot text with bold, bullet lines, and paragraphs cleanly
  const renderFormattedText = (content: string) => {
    const lines = content.split('\n');
    return (
      <div className="space-y-1.5 text-sm leading-relaxed">
        {lines.map((line, idx) => {
          const trimmed = line.trim();
          if (!trimmed) return <div key={idx} className="h-1" />;

          // Bullet points
          const isBullet = trimmed.startsWith('•') || trimmed.startsWith('* ') || trimmed.startsWith('- ');
          const lineText = isBullet ? trimmed.replace(/^[•*-]\s*/, '') : trimmed;

          // Parse bold syntax **text**
          const parts = lineText.split(/(\*\*.*?\*\*)/g);

          return (
            <div key={idx} className={isBullet ? 'flex items-start gap-2 pl-1' : ''}>
              {isBullet && <span className="text-emerald-600 font-bold shrink-0 mt-0.5">•</span>}
              <p className={isBullet ? 'flex-1' : ''}>
                {parts.map((part, pIdx) => {
                  if (part.startsWith('**') && part.endsWith('**')) {
                    return (
                      <strong key={pIdx} className="font-bold text-slate-900">
                        {part.slice(2, -2)}
                      </strong>
                    );
                  }
                  return <span key={pIdx}>{part}</span>;
                })}
              </p>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <>
      {/* Floating Trigger Button (when closed or minimized) */}
      {(!isOpen || isMinimized) && (
        <aside
          aria-label="AI Home Loan Assistant"
          className="fixed bottom-6 left-6 z-40 flex items-center gap-2 group animate-in fade-in duration-300"
        >
          <button
            type="button"
            onClick={() => {
              setIsMinimized(false);
              onOpen();
            }}
            id="floating-ai-chat-btn"
            className="flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#0B192C] hover:bg-[#122846] text-white shadow-xl hover:shadow-2xl border border-emerald-500/40 transition-all hover:scale-105 cursor-pointer"
            aria-label="Open AI Home Loan Assistant"
          >
            <div className="relative flex items-center justify-center w-8 h-8 rounded-full bg-emerald-600 text-white shrink-0 shadow-inner">
              <Bot className="w-5 h-5" />
              <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 border border-[#0B192C] rounded-full animate-ping" />
              <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 border border-[#0B192C] rounded-full" />
            </div>

            <div className="text-left hidden sm:block">
              <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider leading-none">
                {lang === 'hi' ? '24/7 एआई सहायक' : '24/7 AI Advisor'}
              </div>
              <div className="text-xs font-bold text-white leading-tight flex items-center gap-1">
                <span>{lang === 'hi' ? 'होम लोन सवाल पूछें' : 'Ask Home Loan AI'}</span>
                <Sparkles className="w-3 h-3 text-amber-400" />
              </div>
            </div>
          </button>
        </aside>
      )}

      {/* Main Chat Drawer / Window (when open and not minimized) */}
      {isOpen && !isMinimized && (
        <div 
          role="dialog" 
          aria-modal="true" 
          aria-labelledby="ai-chat-title"
          className="fixed inset-x-4 bottom-4 sm:inset-x-auto sm:right-6 sm:bottom-6 sm:w-[420px] md:w-[440px] h-[580px] max-h-[88vh] z-50 flex flex-col bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-200"
        >
          {/* Chat Header */}
          <div className="bg-[#0B192C] text-white p-4 border-b border-slate-800 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 rounded-xl bg-emerald-600/90 border border-emerald-400/40 flex items-center justify-center text-white shadow-xs shrink-0">
                <Bot className="w-6 h-6" />
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-400 border-2 border-[#0B192C] rounded-full" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 id="ai-chat-title" className="text-sm font-bold text-white tracking-tight">
                    Anshfinance AI Sahayak
                  </h3>
                  <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold border border-emerald-500/30">
                    Online
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 font-normal">
                  {lang === 'hi' ? 'होम लोन जानकारी एवं बैंक तुलना' : 'Home Loan Expert & Bank Guide'}
                </p>
              </div>
            </div>

            {/* Header Controls */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleResetChat}
                title={lang === 'hi' ? 'चैट रीसेट करें' : 'Reset chat'}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                aria-label="Reset chat"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setIsMinimized(true)}
                title={lang === 'hi' ? 'न्यूनतम करें' : 'Minimize'}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                aria-label="Minimize chat"
              >
                <ChevronDown className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={onClose}
                title={lang === 'hi' ? 'बंद करें' : 'Close'}
                className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                aria-label="Close chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Direct Expert Contact Bar */}
          <div className="bg-emerald-50 border-b border-emerald-100 px-3.5 py-1.5 flex items-center justify-between text-xs text-emerald-900 shrink-0">
            <div className="flex items-center gap-1.5 font-medium truncate">
              <Building2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <span className="truncate">{BUSINESS_INFO.owner} • इंदौर (Indore)</span>
            </div>
            <a
              href={`tel:${BUSINESS_INFO.phone}`}
              className="flex items-center gap-1 font-bold text-emerald-700 hover:text-emerald-900 transition-colors shrink-0 ml-2"
            >
              <Phone className="w-3 h-3" />
              <span>{BUSINESS_INFO.phone}</span>
            </a>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50 text-slate-900 text-left">
            {messages.map((msg) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[88%] rounded-2xl p-3.5 shadow-xs relative group ${
                      isUser
                        ? 'bg-[#0B192C] text-white rounded-tr-xs'
                        : 'bg-white border border-slate-200 text-slate-800 rounded-tl-xs'
                    }`}
                  >
                    {/* Message Header / Label */}
                    {!isUser && (
                      <div className="flex items-center justify-between gap-2 mb-1.5 pb-1 border-b border-slate-100">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-amber-500" />
                          <span>Anshfinance AI</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopyText(msg.id, msg.text)}
                          title="Copy message"
                          className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
                        >
                          {copiedId === msg.id ? (
                            <Check className="w-3 h-3 text-emerald-600" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                    )}

                    {/* Content */}
                    {isUser ? (
                      <p className="text-sm font-medium whitespace-pre-wrap leading-relaxed">
                        {msg.text}
                      </p>
                    ) : (
                      renderFormattedText(msg.text)
                    )}

                    {/* Timestamp */}
                    <div
                      className={`text-[10px] mt-1.5 text-right font-medium ${
                        isUser ? 'text-slate-300' : 'text-slate-400'
                      }`}
                    >
                      {msg.timestamp}
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Loading / Thinking State */}
            {isLoading && (
              <div className="flex items-start gap-2">
                <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-xs p-3.5 shadow-xs flex items-center gap-2">
                  <div className="flex space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                  <span className="text-xs text-slate-500 font-medium">
                    {lang === 'hi' ? 'उत्तर तैयार हो रहा है...' : 'Formulating response...'}
                  </span>
                </div>
              </div>
            )}

            {/* Quick Suggestions (Shown when initial or user wants more topics) */}
            {messages.length <= 2 && !isLoading && (
              <div className="pt-2 space-y-2">
                <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <FileQuestion className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'hi' ? 'अक्सर पूछे जाने वाले विषय (Quick Topics):' : 'Suggested Topics:'}</span>
                </div>
                <div className="flex flex-col gap-1.5">
                  {suggestions.map((sug, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => handleSend(sug)}
                      className="text-left text-xs bg-white hover:bg-emerald-50 hover:border-emerald-300 border border-slate-200 p-2 rounded-xl text-slate-700 font-medium transition-all shadow-2xs cursor-pointer flex items-center justify-between group"
                    >
                      <span className="line-clamp-1">{sug}</span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-600 shrink-0 ml-1 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Handover to WhatsApp Bar (if interacted) */}
          {hasInteracted && (
            <div className="bg-emerald-50/70 border-t border-emerald-100 px-3 py-1.5 flex items-center justify-between text-xs shrink-0">
              <span className="text-slate-600 font-medium text-[11px]">
                {lang === 'hi' ? 'दीपक जी से इस पर बात करें:' : 'Discuss with Deepak Verma:'}
              </span>
              <a
                href={getWhatsAppChatUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-[11px] font-bold text-[#128C7E] hover:underline"
              >
                <MessageCircle className="w-3 h-3 fill-current" />
                <span>WhatsApp Handover</span>
              </a>
            </div>
          )}

          {/* Input Box Area */}
          <div className="p-3 bg-white border-t border-slate-200 shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={
                  lang === 'hi'
                    ? 'होम लोन, ब्याज दर या दस्तावेज पूछें...'
                    : 'Ask about home loans, eligibility, papers...'
                }
                disabled={isLoading}
                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="w-10 h-10 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 text-white disabled:text-slate-400 flex items-center justify-center shadow-sm transition-all cursor-pointer disabled:cursor-not-allowed shrink-0"
                aria-label="Send query"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

            <div className="flex items-center justify-between mt-1.5 px-1 text-[10px] text-slate-400">
              <span className="flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5 text-emerald-600" />
                <span>Powered by Gemini AI</span>
              </span>
              <span>Anshfinance • Indore</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
