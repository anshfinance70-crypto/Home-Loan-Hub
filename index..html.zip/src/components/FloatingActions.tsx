import React from 'react';
import { Phone, MessageCircle, FileText, Bot } from 'lucide-react';
import { BUSINESS_INFO } from '../data/businessData';
import { Language } from '../types';
import { createWhatsAppUrl } from '../utils/formatters';

interface FloatingActionsProps {
  lang: Language;
  onOpenEnquiry: () => void;
  onOpenAiChat: () => void;
}

export const FloatingActions: React.FC<FloatingActionsProps> = ({ 
  lang, 
  onOpenEnquiry, 
  onOpenAiChat 
}) => {
  const whatsappUrl = createWhatsAppUrl(
    BUSINESS_INFO.whatsapp,
    lang === 'hi'
      ? 'नमस्ते दीपक जी, मुझे Anshfinance से होम लोन के संबंध में सहायता चाहिए।'
      : 'Hello Deepak ji, I would like to inquire about Home Loan assistance with Anshfinance.'
  );

  return (
    <>
      {/* Floating Desktop WhatsApp Button */}
      <aside 
        aria-label="Quick contact buttons" 
        className="fixed bottom-6 right-6 z-40 hidden sm:flex items-center gap-2 group"
      >
        <div className="bg-[#0B192C] text-white text-xs font-medium px-3 py-1.5 rounded-lg shadow-xl border border-slate-700 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none tracking-wide">
          {lang === 'hi' ? 'व्हाट्सएप पर बात करें' : 'Chat on WhatsApp'}
        </div>
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="w-14 h-14 rounded-full bg-[#25D366] hover:bg-[#1EBE5D] text-white flex items-center justify-center shadow-xl hover:scale-105 transition-all relative cursor-pointer border border-emerald-300/60"
          aria-label="Chat on WhatsApp with Anshfinance"
          id="floating-whatsapp-btn"
        >
          <MessageCircle className="w-7 h-7 fill-current" />
          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-white border-2 border-[#25D366] rounded-full flex items-center justify-center animate-pulse" />
        </a>
      </aside>

      {/* Sticky Bottom Action Bar for Mobile Screens */}
      <nav 
        aria-label="Mobile quick action bar" 
        className="fixed bottom-0 inset-x-0 z-40 sm:hidden bg-white/95 backdrop-blur-md border-t border-slate-200 p-2 shadow-2xl"
      >
        <div className="grid grid-cols-4 gap-1.5">
          {/* Call Button */}
          <a
            href={`tel:${BUSINESS_INFO.phone}`}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 text-[10px] font-bold shadow-2xs active:scale-95 transition-transform"
            id="mobile-sticky-call"
          >
            <Phone className="w-4 h-4 text-emerald-600 mb-0.5" />
            <span>{lang === 'hi' ? 'कॉल करें' : 'Call'}</span>
          </a>

          {/* WhatsApp Button */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 text-[10px] font-bold shadow-2xs active:scale-95 transition-transform"
            id="mobile-sticky-whatsapp"
          >
            <MessageCircle className="w-4 h-4 text-emerald-600 fill-current mb-0.5" />
            <span>WhatsApp</span>
          </a>

          {/* AI Chat Button */}
          <button
            type="button"
            onClick={onOpenAiChat}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-emerald-600 text-white text-[10px] font-bold shadow-xs active:scale-95 transition-transform cursor-pointer relative"
            id="mobile-sticky-ai-chat"
          >
            <Bot className="w-4 h-4 mb-0.5" />
            <span>{lang === 'hi' ? 'AI चैट' : 'AI Chat'}</span>
            <span className="absolute top-1 right-2 w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
          </button>

          {/* Apply Button */}
          <button
            type="button"
            onClick={onOpenEnquiry}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-[#0B192C] text-white text-[10px] font-bold shadow-2xs active:scale-95 transition-transform cursor-pointer"
            id="mobile-sticky-apply"
          >
            <FileText className="w-4 h-4 fill-current mb-0.5" />
            <span>{lang === 'hi' ? 'आवेदन' : 'Apply'}</span>
          </button>
        </div>
      </nav>
    </>
  );
};

