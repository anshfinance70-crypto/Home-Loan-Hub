import React, { useState } from 'react';
import { 
  PhoneCall, 
  FileSpreadsheet, 
  SlidersHorizontal, 
  Send, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight,
  Sparkles,
  Phone,
  MessageCircle
} from 'lucide-react';
import { PROCESS_STEPS, BUSINESS_INFO } from '../data/businessData';
import { Language } from '../types';
import { createWhatsAppUrl } from '../utils/formatters';

interface HowItWorksProps {
  lang: Language;
  onOpenEnquiry: () => void;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ lang, onOpenEnquiry }) => {
  const [activeStep, setActiveStep] = useState<number>(1);

  const getStepIcon = (iconName: string) => {
    switch (iconName) {
      case 'PhoneCall': return <PhoneCall className="w-5 h-5" />;
      case 'FileSpreadsheet': return <FileSpreadsheet className="w-5 h-5" />;
      case 'SlidersHorizontal': return <SlidersHorizontal className="w-5 h-5" />;
      case 'Send': return <Send className="w-5 h-5" />;
      case 'ShieldCheck': return <ShieldCheck className="w-5 h-5" />;
      case 'CheckCircle2': return <CheckCircle2 className="w-5 h-5" />;
      default: return <Sparkles className="w-5 h-5" />;
    }
  };

  const whatsappUrl = createWhatsAppUrl(
    BUSINESS_INFO.whatsapp,
    lang === 'hi'
      ? 'नमस्ते दीपक जी, मैं स्टेप 1 (Enquiry) के तहत होम लोन पर बात करना चाहता हूँ।'
      : 'Hello Deepak ji, I would like to start Step 1 (Enquiry) for my Home Loan.'
  );

  return (
    <section id="how-it-works" className="py-20 bg-white border-b border-slate-200 text-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
            <SlidersHorizontal className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'आवेदन से संवितरण तक' : 'Application to Disbursement'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0B192C] tracking-tight">
            {lang === 'hi' ? '📝 How It Works (लोन प्रक्रिया)' : '📝 How It Works (Simple 6 Steps)'}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-normal">
            {lang === 'hi'
              ? 'Anshfinance के साथ होम लोन लेना सरल और व्यवस्थित है। जानिए 6 आसान चरणों की कार्यप्रणाली:'
              : 'Our systematic 6-step roadmap ensures seamless coordination with banks.'}
          </p>
        </div>

        {/* 6 Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PROCESS_STEPS.map((step) => {
            const isSelected = activeStep === step.step;
            return (
              <div
                key={step.step}
                onClick={() => setActiveStep(step.step)}
                className={`p-6 rounded-xl border transition-all cursor-pointer text-left relative flex flex-col justify-between space-y-4 ${
                  isSelected
                    ? 'bg-emerald-50/80 border-emerald-500 shadow-md ring-1 ring-emerald-500/30'
                    : 'bg-slate-50/70 border-slate-200 hover:border-emerald-300 hover:bg-white'
                }`}
              >
                <div className="space-y-3">
                  {/* Step Number Badge and Icon */}
                  <div className="flex items-center justify-between">
                    <span className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm ${
                      isSelected 
                        ? 'bg-emerald-600 text-white shadow-sm' 
                        : 'bg-slate-200/80 text-slate-700'
                    }`}>
                      {getStepIcon(step.iconName)}
                    </span>
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                      isSelected
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}>
                      0{step.step}. Step
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-lg font-bold text-[#0B192C]">
                    {lang === 'hi' ? step.titleHi : step.titleEn}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-slate-600 font-normal leading-relaxed">
                    {lang === 'hi' ? step.descHi : step.descEn}
                  </p>
                </div>

                {/* Sub Action for Step 1 */}
                {step.step === 1 && (
                  <div className="pt-2 flex items-center gap-2">
                    <a
                      href={`tel:${BUSINESS_INFO.phone}`}
                      className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-1.5 bg-[#0B192C] px-3 py-1.5 rounded-lg hover:bg-[#1E3A8A] transition-colors shadow-xs"
                    >
                      <Phone className="w-3 h-3 fill-current" />
                      <span>{lang === 'hi' ? 'कॉल करें' : 'Call'}</span>
                    </a>
                    <a
                      href={whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-1.5 bg-[#25D366] hover:bg-[#1EBE5D] px-3 py-1.5 rounded-lg transition-colors shadow-xs"
                    >
                      <MessageCircle className="w-3 h-3 fill-current" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Quick CTA strip */}
        <div className="p-6 sm:p-8 rounded-2xl bg-[#0B192C] border border-slate-700 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
          <div className="text-left space-y-1">
            <h4 className="text-xl font-bold text-white">
              {lang === 'hi' ? 'स्टेप 1 आज ही शुरू करें!' : 'Ready to start Step 1 today?'}
            </h4>
            <p className="text-xs sm:text-sm text-slate-300 font-normal">
              {lang === 'hi'
                ? 'अपनी आय और जरूरत बताएं, हम आपके लिए उपयुक्त होम लोन विकल्प खोजेंगे।'
                : 'Connect directly with Deepak Verma on Call or WhatsApp for preliminary assessment.'}
            </p>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onOpenEnquiry}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md"
            >
              {lang === 'hi' ? 'इन्क्वायरी फॉर्म भरें' : 'Fill Enquiry Form'}
            </button>
            <a
              href={`tel:${BUSINESS_INFO.phone}`}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>9826686170</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
