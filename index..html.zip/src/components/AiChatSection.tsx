import React, { useState } from 'react';
import { 
  Bot, 
  Sparkles, 
  ArrowRight, 
  Send, 
  ShieldCheck, 
  HelpCircle, 
  MessageSquare, 
  Clock, 
  IndianRupee, 
  FileText,
  Phone
} from 'lucide-react';
import { Language } from '../types';
import { BUSINESS_INFO } from '../data/businessData';

interface AiChatSectionProps {
  lang: Language;
  onOpenChatWithQuery: (query: string) => void;
}

export const AiChatSection: React.FC<AiChatSectionProps> = ({
  lang,
  onOpenChatWithQuery,
}) => {
  const [queryInput, setQueryInput] = useState('');

  const featuredTopics = [
    {
      icon: <FileText className="w-4 h-4 text-emerald-600" />,
      queryHi: 'सैलरीड व्यक्ति को होम लोन के लिए कौन-कौन से दस्तावेज चाहिए?',
      queryEn: 'What documents are required for salaried home loan applicants?',
      tagHi: 'दस्तावेज़ सूची',
      tagEn: 'Documentation'
    },
    {
      icon: <IndianRupee className="w-4 h-4 text-emerald-600" />,
      queryHi: 'वर्तमान में SBI और HDFC की होम लोन ब्याज दरें क्या हैं?',
      queryEn: 'What are the current home loan interest rates for SBI & HDFC?',
      tagHi: 'ब्याज दरें',
      tagEn: 'Interest Rates'
    },
    {
      icon: <ShieldCheck className="w-4 h-4 text-emerald-600" />,
      queryHi: 'CIBIL स्कोर 700 से कम होने पर होम लोन कैसे मिल सकता है?',
      queryEn: 'How to get home loan approval with a low CIBIL score?',
      tagHi: 'सिबिल पात्रता',
      tagEn: 'CIBIL & Eligibility'
    },
    {
      icon: <HelpCircle className="w-4 h-4 text-emerald-600" />,
      queryHi: 'इंदौर में प्लॉट खरीदकर मकान बनाने के लिए लोन प्रक्रिया क्या है?',
      queryEn: 'What is the loan process for plot purchase and house construction in Indore?',
      tagHi: 'प्लॉट + निर्माण',
      tagEn: 'Plot + Construction'
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (queryInput.trim()) {
      onOpenChatWithQuery(queryInput.trim());
      setQueryInput('');
    }
  };

  return (
    <section id="ai-advisor" className="py-20 bg-white border-b border-slate-200 text-slate-900 relative overflow-hidden">
      {/* Subtle Background Glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? '24/7 एआई डिजिटल सलाहकार' : '24/7 Instant AI Advisor'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0B192C] tracking-tight">
            {lang === 'hi' ? '🤖 Anshfinance AI Sahayak से तुरंत पूछें' : '🤖 Ask Anshfinance AI Sahayak Instantly'}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-normal">
            {lang === 'hi'
              ? 'होम लोन पात्रता, जरूरी दस्तावेज, वर्तमान ब्याज दरें या बैंक तुलना — हमारा AI सहायक तुरंत आपके सभी सवालों के सटीक उत्तर देता है।'
              : 'Instant, intelligent answers on home loan eligibility, mandatory bank papers, real-time rates, and bank comparisons.'}
          </p>
        </div>

        {/* Main Interactive Interactive Box */}
        <div className="max-w-4xl mx-auto bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-sm space-y-8 text-left">
          {/* Direct Search / Ask Input */}
          <form onSubmit={handleSubmit} className="relative">
            <div className="flex flex-col sm:flex-row items-center gap-2 bg-white p-2 sm:p-2.5 rounded-2xl border-2 border-slate-200 focus-within:border-emerald-500 shadow-sm transition-colors">
              <div className="flex items-center gap-3 w-full sm:w-auto flex-1 px-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-100/80 text-emerald-800 flex items-center justify-center shrink-0">
                  <Bot className="w-5 h-5" />
                </div>
                <input
                  type="text"
                  value={queryInput}
                  onChange={(e) => setQueryInput(e.target.value)}
                  placeholder={
                    lang === 'hi'
                      ? 'उदा. "50 लाख के लोन पर कितनी सैलरी चाहिए?" या कोई भी प्रश्न...'
                      : 'e.g. "What salary is required for 50 Lakh home loan?" or any doubt...'
                  }
                  className="w-full bg-transparent text-sm sm:text-base text-slate-800 placeholder-slate-400 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-[#0B192C] hover:bg-emerald-700 text-white font-bold text-sm tracking-wide flex items-center justify-center gap-2 transition-all shadow-sm cursor-pointer shrink-0"
              >
                <span>{lang === 'hi' ? 'AI से उत्तर पाएं' : 'Ask AI'}</span>
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>

          {/* Quick Clickable Topic Cards */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-500">
              <span>{lang === 'hi' ? 'अक्सर पूछे जाने वाले सवाल (क्लिक करें):' : 'Popular Questions (Click to Ask):'}</span>
              <span className="text-emerald-700 font-semibold flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'तुरंत जवाब' : 'Instant Reply'}</span>
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {featuredTopics.map((topic, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => onOpenChatWithQuery(lang === 'hi' ? topic.queryHi : topic.queryEn)}
                  className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-emerald-500 hover:shadow-md transition-all text-left flex items-start gap-3 group cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-emerald-100 transition-colors">
                    {topic.icon}
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wide">
                        {lang === 'hi' ? topic.tagHi : topic.tagEn}
                      </span>
                      <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all" />
                    </div>
                    <p className="text-sm font-medium text-slate-800 leading-snug group-hover:text-emerald-900 transition-colors">
                      {lang === 'hi' ? topic.queryHi : topic.queryEn}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Advisor Assurance Footer */}
          <div className="pt-4 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                {lang === 'hi'
                  ? 'AI उत्तर सामान्य मार्गदर्शन हेतु हैं। फाइल प्रोसेसिंग एवं बैंक अप्रूवल के लिए व्यक्तिगत सहयोग उपलब्ध है।'
                  : 'AI responses provide educational guidance. Personalized sanction support is provided directly by Deepak Verma.'}
              </span>
            </div>

            <a
              href={`tel:${BUSINESS_INFO.phone}`}
              className="inline-flex items-center gap-1.5 font-bold text-[#0B192C] hover:text-emerald-600 transition-colors shrink-0 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-2xs"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-600" />
              <span>कॉल करें: {BUSINESS_INFO.phoneFormatted}</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
