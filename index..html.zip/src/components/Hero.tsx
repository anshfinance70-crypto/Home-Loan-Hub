import React from 'react';
import { 
  Phone, 
  MessageCircle, 
  ArrowRight, 
  CheckCircle2, 
  ShieldCheck, 
  Building2, 
  Clock, 
  MapPin, 
  Sparkles,
  Award,
  Bot
} from 'lucide-react';
import { BUSINESS_INFO, BANK_NETWORK_DISCLAIMER } from '../data/businessData';
import { Language } from '../types';
import { createWhatsAppUrl } from '../utils/formatters';

interface HeroProps {
  lang: Language;
  onOpenEnquiry: () => void;
  onOpenAiChat?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ lang, onOpenEnquiry, onOpenAiChat }) => {
  const whatsappUrl = createWhatsAppUrl(
    BUSINESS_INFO.whatsapp,
    lang === 'hi'
      ? 'नमस्ते दीपक जी (Anshfinance), मुझे नए होम लोन / प्रक्रिया के संबंध में सहायता चाहिए।'
      : 'Hello Deepak ji (Anshfinance), I need guidance regarding a Home Loan application.'
  );

  return (
    <section id="home" className="relative overflow-hidden bg-gradient-to-b from-slate-50 via-white to-slate-50 text-slate-900 pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-slate-200">
      {/* Background Subtle Accent Grids */}
      <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#CBD5E1_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />
      
      {/* Decorative Subtle Ambient Glow */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[550px] h-[550px] bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Content */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Trust Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>
                {lang === 'hi'
                  ? 'इंदौर का विश्वसनीय होम लोन परामर्श • दीपक वर्मा'
                  : 'Trusted Home Loan Guidance in Indore • Deepak Verma'}
              </span>
            </div>

            {/* Brand Title & Tagline */}
            <div className="space-y-2">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#0B192C] leading-[1.1]">
                {BUSINESS_INFO.name}
              </h1>
              <div className="text-2xl sm:text-3xl lg:text-4xl font-serif text-emerald-700 italic leading-snug font-medium">
                “{BUSINESS_INFO.tagline[lang]}”
              </div>
            </div>

            {/* Core Value Description */}
            <p className="text-base sm:text-lg text-slate-600 font-normal max-w-2xl leading-relaxed">
              {BUSINESS_INFO.subTagline[lang]}
            </p>

            {/* Responsible Network Badge */}
            <div className="p-4 rounded-xl bg-white border border-slate-200 text-xs sm:text-sm text-slate-700 flex items-start gap-3.5 shadow-xs">
              <Building2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-[#0B192C] tracking-wide uppercase text-xs">
                  {lang === 'hi' ? 'विश्वसनीय बैंक नेटवर्क: ' : 'Bank Network: '}
                </span>
                <span className="text-slate-600 font-normal">{BANK_NETWORK_DISCLAIMER[lang]}</span>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              {/* Button 1: Apply for Home Loan */}
              <button
                onClick={onOpenEnquiry}
                id="hero-apply-btn"
                className="flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm uppercase tracking-wider shadow-md hover:shadow-lg transition-all cursor-pointer"
              >
                <span>{lang === 'hi' ? 'Apply for Home Loan' : 'Apply for Home Loan'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Button 2: WhatsApp Us */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                id="hero-whatsapp-btn"
                className="flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-[#25D366] hover:bg-[#1EBE5D] text-white font-bold text-xs sm:text-sm uppercase tracking-wider shadow-md hover:shadow-lg transition-all"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>{lang === 'hi' ? 'WhatsApp Us' : 'WhatsApp Us'}</span>
              </a>

              {/* Button 3: Call Now */}
              <a
                href={`tel:${BUSINESS_INFO.phone}`}
                id="hero-call-btn"
                className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl border border-slate-300 hover:border-slate-400 bg-white text-[#0B192C] hover:bg-slate-50 font-bold text-xs sm:text-sm uppercase tracking-wider transition-all shadow-xs"
              >
                <Phone className="w-4 h-4 text-emerald-600 fill-current" />
                <span>{lang === 'hi' ? 'Call Now' : 'Call Now'}</span>
              </a>
            </div>

            {/* Quick AI Advisor Prompt Trigger */}
            {onOpenAiChat && (
              <div className="pt-1">
                <button
                  type="button"
                  onClick={onOpenAiChat}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold transition-all shadow-2xs cursor-pointer group"
                >
                  <Bot className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" />
                  <span>{lang === 'hi' ? '💬 कोई प्रश्न है? 24/7 AI होम लोन सहायक से पूछें' : '💬 Have questions? Ask our 24/7 Home Loan AI'}</span>
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                </button>
              </div>
            )}

            {/* Micro Trust Stats Strip */}
            <div className="mt-8 flex flex-wrap gap-8 items-center border-t border-slate-200 pt-6 text-left">
              <div className="flex flex-col">
                <span className="text-[#0B192C] text-2xl font-bold font-serif">All Major</span>
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Banks & NBFCs</span>
              </div>
              <div className="h-8 w-px bg-slate-200 hidden sm:block"></div>
              <div className="flex flex-col">
                <span className="text-[#0B192C] text-2xl font-bold font-serif">Indore</span>
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Arihant Nagar</span>
              </div>
              <div className="h-8 w-px bg-slate-200 hidden sm:block"></div>
              <div className="flex flex-col">
                <span className="text-[#0B192C] text-2xl font-bold font-serif">7 AM — 10 PM</span>
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Open 7 Days a Week</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual & Floating Consultation Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-200 shadow-xl bg-white">
              {/* Generated Dream Home Image */}
              <img
                src="/src/assets/images/indian_dream_home_1787896943852.jpg"
                alt="Beautiful Modern Home Loan Dream House"
                className="w-full h-80 sm:h-96 object-cover object-center filter brightness-95 hover:scale-102 transition-all duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-900/30 to-transparent" />

              {/* Overlay Content */}
              <div className="absolute bottom-0 inset-x-0 p-6 space-y-2 text-left">
                <div className="inline-block px-3 py-1 bg-emerald-500 text-white font-bold text-[11px] uppercase tracking-wider rounded-md">
                  {lang === 'hi' ? 'घर आपका, साथ हमारा' : 'Your Dream Home Loan'}
                </div>
                <h3 className="text-xl font-serif font-bold text-white leading-tight">
                  {lang === 'hi' ? 'सरल व निष्पक्ष होम लोन मार्गदर्शन' : 'Simple & Unbiased Home Loan Guidance'}
                </h3>
                <p className="text-xs text-slate-200 font-light">
                  {lang === 'hi' 
                    ? '265-B, अरिहंत नगर, गोम्मटगिरि के पास, इंदौर में व्यक्तिगत सेवा'
                    : 'Personalized service at 265-B, Arihant Nagar, Near Gommatgiri, Indore'}
                </p>
              </div>
            </div>

            {/* Quick Contact Badge / Floating Card */}
            <div className="absolute -bottom-6 -left-3 sm:-left-6 bg-white/95 backdrop-blur-md text-slate-900 rounded-xl p-4 shadow-xl border border-slate-200 flex items-center gap-3.5 max-w-xs z-20">
              <div className="w-11 h-11 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                  {lang === 'hi' ? 'सीधा संपर्क (दीपक वर्मा)' : 'Direct Advisor (Deepak Verma)'}
                </div>
                <a 
                  href={`tel:${BUSINESS_INFO.phone}`} 
                  className="text-base font-bold text-[#0B192C] hover:text-emerald-600 block leading-tight tracking-wider"
                >
                  {BUSINESS_INFO.phoneFormatted}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
