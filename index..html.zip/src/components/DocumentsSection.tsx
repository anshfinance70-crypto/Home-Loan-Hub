import React, { useState } from 'react';
import { 
  FileText, 
  CheckSquare, 
  Square, 
  AlertTriangle, 
  Copy, 
  Check, 
  MessageCircle, 
  Briefcase, 
  Building, 
  FileBadge 
} from 'lucide-react';
import { DOCUMENTS_LIST, BUSINESS_INFO } from '../data/businessData';
import { Language } from '../types';
import { createWhatsAppUrl } from '../utils/formatters';

interface DocumentsSectionProps {
  lang: Language;
}

export const DocumentsSection: React.FC<DocumentsSectionProps> = ({ lang }) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'salaried' | 'self_employed' | 'property'>('all');
  const [checkedItems, setCheckedItems] = useState<Record<number, boolean>>({});
  const [copied, setCopied] = useState(false);

  const toggleCheck = (index: number) => {
    setCheckedItems(prev => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  const filteredDocs = DOCUMENTS_LIST.filter(doc => {
    if (selectedCategory === 'all') return true;
    if (selectedCategory === 'salaried') return doc.category === 'salaried' || doc.category === 'general';
    if (selectedCategory === 'self_employed') return doc.category === 'self_employed' || doc.category === 'general';
    if (selectedCategory === 'property') return doc.category === 'property';
    return true;
  });

  const handleCopyChecklist = () => {
    const text = DOCUMENTS_LIST.map((doc, idx) => `${idx + 1}. ${doc.nameHi}\n   - ${doc.detailHi}`).join('\n\n');
    navigator.clipboard.writeText(`Anshfinance - Home Loan Required Documents Checklist:\n\n${text}\n\nContact Deepak Verma: 9826686170 (Indore)`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const shareOnWhatsApp = () => {
    const text = `नमस्ते दीपक जी (Anshfinance), मुझे होम लोन के आवश्यक दस्तावेजों की सूची और फाइल तैयार करने में सहायता चाहिए।`;
    window.open(createWhatsAppUrl(BUSINESS_INFO.whatsapp, text), '_blank');
  };

  return (
    <section id="documents" className="py-20 bg-slate-50 border-b border-slate-200 text-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
            <FileText className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'दस्तावेज चेकलिस्ट' : 'Document Checklist'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0B192C] tracking-tight">
            {lang === 'hi' ? '📄 आमतौर पर आवश्यक Documents' : '📄 Essential Documents Required for Home Loan'}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-normal">
            {lang === 'hi'
              ? 'होम लोन आवेदन के लिए तैयार रखने योग्य प्रमुख पहचान, आय और प्रॉपर्टी दस्तावेजों की सूची।'
              : 'Keep these standard KYC, income, banking, and property documents prepared for smooth processing.'}
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-emerald-600 text-white font-bold shadow-xs'
                : 'bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:border-emerald-300'
            }`}
          >
            {lang === 'hi' ? 'सभी दस्तावेज (All)' : 'All Documents'}
          </button>
          <button
            onClick={() => setSelectedCategory('salaried')}
            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedCategory === 'salaried'
                ? 'bg-emerald-600 text-white font-bold shadow-xs'
                : 'bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:border-emerald-300'
            }`}
          >
            {lang === 'hi' ? 'वेतनभोगी (Salaried)' : 'Salaried Employees'}
          </button>
          <button
            onClick={() => setSelectedCategory('self_employed')}
            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedCategory === 'self_employed'
                ? 'bg-emerald-600 text-white font-bold shadow-xs'
                : 'bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:border-emerald-300'
            }`}
          >
            {lang === 'hi' ? 'व्यवसायी (Self-Employed)' : 'Self-Employed / Business'}
          </button>
          <button
            onClick={() => setSelectedCategory('property')}
            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedCategory === 'property'
                ? 'bg-emerald-600 text-white font-bold shadow-xs'
                : 'bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:border-emerald-300'
            }`}
          >
            {lang === 'hi' ? 'प्रॉपर्टी दस्तावेज (Property)' : 'Property Documents'}
          </button>
        </div>

        {/* Documents Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredDocs.map((doc, idx) => {
            const isChecked = !!checkedItems[idx];
            return (
              <div
                key={idx}
                onClick={() => toggleCheck(idx)}
                className={`p-5 rounded-xl border transition-all cursor-pointer text-left flex items-start gap-4 ${
                  isChecked
                    ? 'bg-emerald-50/70 border-emerald-300 shadow-xs'
                    : 'bg-white border-slate-200 hover:border-emerald-300 hover:shadow-xs'
                }`}
              >
                <button 
                  type="button" 
                  className="mt-0.5 focus:outline-hidden"
                  aria-label="Toggle document ready state"
                >
                  {isChecked ? (
                    <CheckSquare className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <Square className="w-5 h-5 text-slate-300" />
                  )}
                </button>

                <div className="space-y-1 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className={`text-base font-bold ${isChecked ? 'text-slate-400 line-through' : 'text-[#0B192C]'}`}>
                      {lang === 'hi' ? doc.nameHi : doc.nameEn}
                    </h3>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                      {doc.category}
                    </span>
                  </div>
                  <p className={`text-xs sm:text-sm font-normal ${isChecked ? 'text-slate-400' : 'text-slate-600'}`}>
                    {lang === 'hi' ? doc.detailHi : doc.detailEn}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Important Disclaimer as requested verbatim */}
        <div className="p-5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-left flex items-start gap-3 shadow-xs">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="font-bold text-sm text-amber-900 uppercase tracking-wider">
              {lang === 'hi' ? 'महत्वपूर्ण सूचना (Important Disclaimer):' : 'Important Note:'}
            </h4>
            <p className="text-xs sm:text-sm leading-relaxed text-amber-800 font-normal">
              {lang === 'hi'
                ? 'Important: Exact documents applicant की profile और lender की requirements पर निर्भर करेंगे।'
                : 'Important: The exact list of documents will strictly depend on the applicant’s specific profile (salaried, business, professional) and the underwriting norms of the chosen lending bank/NBFC.'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
          <button
            onClick={handleCopyChecklist}
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-emerald-600" />}
            <span>{copied ? (lang === 'hi' ? 'कॉपी हो गया!' : 'Copied!') : (lang === 'hi' ? 'दस्तावेज सूची कॉपी करें' : 'Copy Document List')}</span>
          </button>

          <button
            onClick={shareOnWhatsApp}
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-md"
          >
            <MessageCircle className="w-4 h-4 fill-current" />
            <span>{lang === 'hi' ? 'दस्तावेज जांच हेतु WhatsApp पर भेजें' : 'Consult Documents on WhatsApp'}</span>
          </button>
        </div>
      </div>
    </section>
  );
};
