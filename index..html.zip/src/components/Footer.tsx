import React from 'react';
import { 
  Home, 
  Phone, 
  MessageCircle, 
  Mail, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  ArrowUp,
  ExternalLink 
} from 'lucide-react';
import { 
  BUSINESS_INFO, 
  BANK_NETWORK_DISCLAIMER, 
  REGULATORY_NOTE 
} from '../data/businessData';
import { Language } from '../types';
import { createWhatsAppUrl } from '../utils/formatters';

interface FooterProps {
  lang: Language;
}

export const Footer: React.FC<FooterProps> = ({ lang }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const defaultWaUrl = createWhatsAppUrl(
    BUSINESS_INFO.whatsapp,
    lang === 'hi'
      ? 'नमस्ते दीपक जी (Anshfinance), मुझे होम लोन से संबंधित जानकारी चाहिए।'
      : 'Hello Deepak ji (Anshfinance), I would like to inquire about home loans.'
  );

  return (
    <footer className="bg-[#0B192C] text-slate-400 text-xs sm:text-sm pt-16 pb-28 sm:pb-16 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 text-left">
          {/* Brand Col */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center font-bold">
                <Home className="w-5 h-5" />
              </div>
              <div>
                <span className="text-2xl font-bold text-white tracking-tight">
                  Ansh<span className="text-emerald-400">finance</span>
                </span>
                <p className="text-[11px] text-slate-400 font-medium">
                  {BUSINESS_INFO.category} • {BUSINESS_INFO.owner}
                </p>
              </div>
            </div>

            <p className="text-sm font-medium italic text-emerald-300/90">
              “{BUSINESS_INFO.tagline[lang]}”
            </p>

            <p className="text-xs text-slate-300 max-w-sm leading-relaxed font-normal">
              {lang === 'hi'
                ? 'Anshfinance एक समर्पित Home Loan service business है, जिसका उद्देश्य ग्राहकों को उनके घर के सपने को पूरा करने के लिए Home Loan process में उचित और निष्पक्ष सहायता प्रदान करना है।'
                : 'Anshfinance is a dedicated Home Loan consultancy helping home buyers navigate bank procedures, legal documentation, and rate comparisons.'}
            </p>

            <div className="pt-2 flex items-center gap-3">
              <a
                href={`tel:${BUSINESS_INFO.phone}`}
                className="px-3.5 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-white border border-white/15 flex items-center gap-1.5 text-xs font-semibold transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Call {BUSINESS_INFO.phone}</span>
              </a>

              <a
                href={defaultWaUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-2 rounded-lg bg-[#25D366] hover:bg-[#1EBE5D] text-white flex items-center gap-1.5 text-xs font-bold transition-colors shadow-sm"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-current" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs uppercase font-bold tracking-wider text-slate-200">
              {lang === 'hi' ? 'त्वरित नेविगेशन' : 'Quick Navigation'}
            </h4>
            <ul className="space-y-2 text-xs font-normal">
              <li>
                <a href="#home" className="hover:text-emerald-400 transition-colors">
                  {lang === 'hi' ? 'मुख्य पृष्ठ (Home)' : 'Home'}
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-emerald-400 transition-colors">
                  {lang === 'hi' ? 'हमारे बारे में (About Us)' : 'About Us'}
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-emerald-400 transition-colors">
                  {lang === 'hi' ? 'होम लोन सेवा (Home Loan Service)' : 'Our Services'}
                </a>
              </li>
              <li>
                <a href="#how-it-works" className="hover:text-emerald-400 transition-colors">
                  {lang === 'hi' ? 'कार्यप्रणाली (How It Works)' : 'How It Works (6 Steps)'}
                </a>
              </li>
              <li>
                <a href="#documents" className="hover:text-emerald-400 transition-colors">
                  {lang === 'hi' ? 'आवश्यक दस्तावेज (Documents)' : 'Required Documents'}
                </a>
              </li>
              <li>
                <a href="#calculator" className="hover:text-emerald-400 transition-colors">
                  {lang === 'hi' ? 'ईएमआई कैलकुलेटर (EMI Calculator)' : 'EMI Calculator'}
                </a>
              </li>
              <li>
                <a href="#why-us" className="hover:text-emerald-400 transition-colors">
                  {lang === 'hi' ? 'विशेषताएं (Why Choose Us)' : 'Why Choose Anshfinance'}
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-emerald-400 transition-colors">
                  {lang === 'hi' ? 'संपर्क करें (Contact)' : 'Contact Us'}
                </a>
              </li>
            </ul>
          </div>

          {/* Office & Timings */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs uppercase font-bold tracking-wider text-slate-200">
              {lang === 'hi' ? 'कार्यालय एवं संपर्क विवरण' : 'Office & Contacts'}
            </h4>
            <div className="space-y-2.5 text-xs">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-white font-semibold">{BUSINESS_INFO.location}, Indore</div>
                  <div className="text-slate-400">Nearby: {BUSINESS_INFO.nearby}, Madhya Pradesh</div>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-white font-medium">{BUSINESS_INFO.workingHours[lang]}</div>
                  <div className="text-slate-400">7 Days a Week</div>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`tel:${BUSINESS_INFO.phone}`} className="text-white hover:text-emerald-400 font-medium transition-colors">
                  {BUSINESS_INFO.phone}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`mailto:${BUSINESS_INFO.email}`} className="text-white hover:text-emerald-400 font-medium break-all transition-colors">
                  {BUSINESS_INFO.email}
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Responsible Disclaimer Box */}
        <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-[11px] text-slate-400 leading-relaxed text-left space-y-1.5 font-normal">
          <p className="font-semibold text-slate-200">
            {BANK_NETWORK_DISCLAIMER[lang]}
          </p>
          <p className="text-slate-400">
            {REGULATORY_NOTE[lang]}
          </p>
        </div>

        {/* Bottom Strip */}
        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            © {new Date().getFullYear()} <strong className="text-white font-bold">Anshfinance</strong>. All rights reserved. Directed by Deepak Verma, Indore.
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
          >
            <span>{lang === 'hi' ? 'ऊपर जाएं' : 'Back to Top'}</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
