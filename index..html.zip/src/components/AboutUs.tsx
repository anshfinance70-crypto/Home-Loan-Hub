import React from 'react';
import { 
  User, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  CheckCircle, 
  Phone, 
  MessageCircle, 
  Sparkles,
  Building,
  Target
} from 'lucide-react';
import { BUSINESS_INFO } from '../data/businessData';
import { Language } from '../types';
import { createWhatsAppUrl } from '../utils/formatters';

interface AboutUsProps {
  lang: Language;
}

export const AboutUs: React.FC<AboutUsProps> = ({ lang }) => {
  const whatsappUrl = createWhatsAppUrl(
    BUSINESS_INFO.whatsapp,
    lang === 'hi'
      ? 'नमस्ते दीपक जी, मैं Anshfinance के होम लोन मार्गदर्शन के बारे में अधिक जानना चाहता हूँ।'
      : 'Hello Deepak ji, I would like to know more about Anshfinance home loan guidance.'
  );

  return (
    <section id="about" className="py-20 bg-white border-b border-slate-200 text-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider shadow-xs">
            <User className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'hi' ? 'हमारे बारे में' : 'About Us'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0B192C] tracking-tight">
            {lang === 'hi' 
              ? 'Anshfinance — आपके घर के सपने का विश्वसनीय साथी' 
              : 'Anshfinance — Your Reliable Home Loan Companion'}
          </h2>
          <p className="text-base sm:text-lg text-slate-600 font-normal">
            {lang === 'hi'
              ? 'सरल, पारदर्शी और पेशेवर होम लोन सहायता इंदौर में'
              : 'Simple, transparent, and professional home loan assistance in Indore'}
          </p>
        </div>

        {/* Two Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Advisor Image & Credentials Badge */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border border-slate-200 bg-slate-900">
              <img
                src="/src/assets/images/home_loan_advisor_1787896966256.jpg"
                alt="Deepak Verma - Home Loan Advisor Anshfinance"
                className="w-full h-96 object-cover object-top filter brightness-95"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-900/30 to-transparent" />
              
              <div className="absolute bottom-4 inset-x-4 text-white">
                <div className="text-2xl font-serif font-bold text-white tracking-wide">{BUSINESS_INFO.owner}</div>
                <div className="text-xs uppercase tracking-wider text-emerald-400 font-bold mt-0.5">
                  {lang === 'hi' ? 'संस्थापक एवं होम लोन सलाहकार' : 'Founder & Home Loan Advisor'}
                </div>
                <div className="text-xs text-slate-300 font-mono mt-1.5 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{BUSINESS_INFO.location}, {BUSINESS_INFO.city}</span>
                </div>
              </div>
            </div>

            {/* Floating Trust Card */}
            <div className="mt-4 sm:mt-0 sm:absolute sm:-bottom-6 sm:-right-6 bg-white/95 backdrop-blur-md text-slate-900 p-4 rounded-xl shadow-xl border border-slate-200 text-xs space-y-1.5 max-w-xs">
              <div className="flex items-center gap-2 font-bold text-emerald-700 uppercase tracking-wider text-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>{lang === 'hi' ? 'सत्यनिष्ठ परामर्श' : 'Ethical Consultation'}</span>
              </div>
              <p className="text-slate-600 font-normal leading-relaxed">
                {lang === 'hi' 
                  ? 'कोई झूठी गारंटी नहीं, केवल बैंक नियमों के अनुसार उचित प्रक्रिया।'
                  : 'No false guarantees — strict alignment with lender guidelines.'}
              </p>
            </div>
          </div>

          {/* Right Column: Detailed Narrative */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="space-y-4 text-slate-700 font-normal leading-relaxed">
              <p className="text-base sm:text-lg">
                <strong className="font-bold text-[#0B192C] text-xl">Anshfinance</strong> {lang === 'hi'
                  ? 'एक समर्पित Home Loan service business है, जिसका मुख्य उद्देश्य ग्राहकों को उनके घर के सपने को साकार करने के लिए होम लोन प्रक्रिया में उचित, निष्पक्ष और पारदर्शी सहायता प्रदान करना है।'
                  : 'is a dedicated Home Loan advisory service based in Indore, committed to guiding families and individuals through every phase of financing their dream home.'}
              </p>

              <p className="text-base text-slate-600">
                {lang === 'hi'
                  ? 'हमारा प्राथमिक focus यह है कि ग्राहक को जटिल बैंकिंग प्रक्रियाओं, दस्तावेजीकरण और विभिन्न वित्तीय विकल्पों को समझने में सरल और professional assistance प्राप्त हो सके।'
                  : 'Our primary focus is to demystify complex banking procedures, interest rate comparisons, and eligibility criteria so you can make confident, stress-free decisions.'}
              </p>
            </div>

            {/* Core Info Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1 hover:border-emerald-300 hover:shadow-xs transition-all">
                <div className="flex items-center gap-2 text-emerald-700 font-mono text-xs font-bold uppercase tracking-wider">
                  <User className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'hi' ? 'संचालक (Owner)' : 'Leadership'}</span>
                </div>
                <div className="text-lg font-bold text-[#0B192C]">{BUSINESS_INFO.owner}</div>
                <p className="text-xs text-slate-500 font-normal">
                  {lang === 'hi' ? 'व्यक्तिगत ध्यान व परामर्श' : 'Direct, personal guidance on all loan files'}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1 hover:border-emerald-300 hover:shadow-xs transition-all">
                <div className="flex items-center gap-2 text-emerald-700 font-mono text-xs font-bold uppercase tracking-wider">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'hi' ? 'स्थान (Location)' : 'Location'}</span>
                </div>
                <div className="text-lg font-bold text-[#0B192C]">{BUSINESS_INFO.location}</div>
                <p className="text-xs text-slate-500 font-normal">
                  {lang === 'hi' ? 'गोम्मटगिरि के पास, इंदौर (म.प्र.)' : 'Near Gommatgiri, Indore (M.P.)'}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1 hover:border-emerald-300 hover:shadow-xs transition-all">
                <div className="flex items-center gap-2 text-emerald-700 font-mono text-xs font-bold uppercase tracking-wider">
                  <Clock className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'hi' ? 'कार्य समय (Hours)' : 'Working Hours'}</span>
                </div>
                <div className="text-lg font-bold text-[#0B192C]">
                  {lang === 'hi' ? 'सुबह 7:00 से रात 10:00 तक' : '7:00 AM – 10:00 PM'}
                </div>
                <p className="text-xs text-slate-500 font-normal">
                  {lang === 'hi' ? 'सप्ताह के सातों दिन उपलब्ध' : 'Open 7 days a week for inquiries'}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1 hover:border-emerald-300 hover:shadow-xs transition-all">
                <div className="flex items-center gap-2 text-emerald-700 font-mono text-xs font-bold uppercase tracking-wider">
                  <Building className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'hi' ? 'बैंक नेटवर्क' : 'Multi-Bank Network'}</span>
                </div>
                <div className="text-lg font-bold text-[#0B192C]">
                  {lang === 'hi' ? 'प्रमुख Banks व NBFCs' : 'Leading Banks & NBFCs'}
                </div>
                <p className="text-xs text-slate-500 font-normal">
                  {lang === 'hi' ? 'प्रोफाइल अनुसार सर्वोत्तम विकल्प' : 'Best match for your financial profile'}
                </p>
              </div>
            </div>

            {/* Communication CTA Row */}
            <div className="pt-3 flex flex-wrap items-center gap-4">
              <a
                href={`tel:${BUSINESS_INFO.phone}`}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-[#0B192C] hover:bg-[#1E3A8A] text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md"
              >
                <Phone className="w-4 h-4 fill-current" />
                <span>{lang === 'hi' ? 'दीपक वर्मा जी से कॉल पर बात करें' : 'Call Deepak Verma'}</span>
              </a>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold text-xs uppercase tracking-wider transition-all shadow-xs"
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>{lang === 'hi' ? 'WhatsApp पर मैसेज भेजें' : 'Message on WhatsApp'}</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
