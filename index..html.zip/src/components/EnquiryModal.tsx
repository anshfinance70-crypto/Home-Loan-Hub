import React, { useState } from 'react';
import { X, Send, Phone, MessageCircle, Home, CheckCircle2 } from 'lucide-react';
import { BUSINESS_INFO } from '../data/businessData';
import { Language, LoanEnquiryForm } from '../types';
import { createWhatsAppUrl } from '../utils/formatters';

interface EnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const EnquiryModal: React.FC<EnquiryModalProps> = ({ isOpen, onClose, lang }) => {
  const [formData, setFormData] = useState<LoanEnquiryForm>({
    name: '',
    phone: '',
    loanAmount: '₹30 Lakhs',
    loanPurpose: 'New Home Purchase',
    employmentType: 'Salaried',
    preferredCallTime: 'Anytime',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;

    const message = `🏠 *Home Loan Application Enquiry — Anshfinance*\n\n` +
      `👤 *Name:* ${formData.name}\n` +
      `📞 *Phone:* ${formData.phone}\n` +
      `💰 *Amount:* ${formData.loanAmount}\n` +
      `🎯 *Purpose:* ${formData.loanPurpose}\n` +
      `💼 *Employment:* ${formData.employmentType}\n` +
      `⏰ *Preferred Time:* ${formData.preferredCallTime}\n` +
      `📝 *Details:* ${formData.message || 'Indore'}`;

    window.open(createWhatsAppUrl(BUSINESS_INFO.whatsapp, message), '_blank');
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-white text-slate-900 rounded-2xl shadow-2xl border border-slate-200 overflow-hidden text-left">
        {/* Header */}
        <div className="bg-[#0B192C] text-white p-6 flex justify-between items-start border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
              <Home className="w-4 h-4 text-emerald-400" />
              <span>Anshfinance — {BUSINESS_INFO.owner}</span>
            </div>
            <h3 className="text-xl font-bold text-white mt-1">
              {lang === 'hi' ? 'Apply for Home Loan' : 'Apply for Home Loan'}
            </h3>
            <p className="text-xs text-slate-300 font-normal mt-0.5">
              {BUSINESS_INFO.tagline[lang]}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="py-8 text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-bold text-[#0B192C]">
                {lang === 'hi' ? 'आपकी पूछताछ प्रेषित कर दी गई है!' : 'Your Inquiry has been sent!'}
              </h4>
              <p className="text-xs text-slate-600 max-w-xs mx-auto font-normal">
                दीपक वर्मा (Anshfinance) द्वारा शीघ्र ही 9826686170 से आपसे चर्चा की जाएगी।
              </p>
              <button
                onClick={() => {
                  setSubmitted(false);
                  onClose();
                }}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider cursor-pointer shadow-xs transition-colors"
              >
                {lang === 'hi' ? 'समाप्त करें' : 'Close'}
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  {lang === 'hi' ? 'नाम (Name) *' : 'Name *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder="उदा. अमित कुमार"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  {lang === 'hi' ? 'मोबाइल नंबर (Phone) *' : 'Phone / WhatsApp *'}
                </label>
                <input
                  type="tel"
                  required
                  placeholder="98266XXXXX"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    {lang === 'hi' ? 'अपेक्षित लोन राशि' : 'Loan Amount'}
                  </label>
                  <select
                    value={formData.loanAmount}
                    onChange={(e) => setFormData({ ...formData, loanAmount: e.target.value })}
                    className="w-full px-3 py-2.5 text-xs font-medium rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
                  >
                    <option>₹15 - 25 Lakhs</option>
                    <option>₹25 - 40 Lakhs</option>
                    <option>₹40 - 60 Lakhs</option>
                    <option>₹60 - 80 Lakhs</option>
                    <option>₹80 Lakhs - ₹1.5 Cr</option>
                    <option>₹1.5 Cr+</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    {lang === 'hi' ? 'कार्य / पेशा' : 'Employment'}
                  </label>
                  <select
                    value={formData.employmentType}
                    onChange={(e) => setFormData({ ...formData, employmentType: e.target.value })}
                    className="w-full px-3 py-2.5 text-xs font-medium rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
                  >
                    <option>Salaried (नौकरीपेशा)</option>
                    <option>Business (व्यापारी)</option>
                    <option>Self-Employed (पेशेवर)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  {lang === 'hi' ? 'प्रॉपर्टी का विवरण / संदेश (वैकल्पिक)' : 'Notes / Location in Indore'}
                </label>
                <textarea
                  rows={2}
                  placeholder="उदा. इंदौर में मकान निर्माण अथवा नया फ्लैट..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 focus:bg-white transition-all"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
                >
                  <Send className="w-4 h-4 fill-current" />
                  <span>{lang === 'hi' ? 'WhatsApp पर आवेदन भेजें' : 'Submit via WhatsApp'}</span>
                </button>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 font-medium pt-1">
                <span>📞 सीधा कॉल: 9826686170</span>
                <span>⏰ 7:00 AM - 10:00 PM</span>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
