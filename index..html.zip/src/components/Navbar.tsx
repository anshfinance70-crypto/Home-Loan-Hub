import React, { useState } from 'react';
import { 
  Phone, 
  MessageCircle, 
  Clock, 
  MapPin, 
  Menu, 
  X, 
  Home, 
  FileText, 
  Calculator, 
  HelpCircle, 
  CheckCircle,
  Languages,
  Bot,
  Sparkles
} from 'lucide-react';
import { BUSINESS_INFO } from '../data/businessData';
import { Language } from '../types';
import { createWhatsAppUrl } from '../utils/formatters';

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  onOpenEnquiry: () => void;
  onOpenAiChat: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ lang, onToggleLang, onOpenEnquiry, onOpenAiChat }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const defaultWaUrl = createWhatsAppUrl(
    BUSINESS_INFO.whatsapp,
    lang === 'hi'
      ? 'नमस्ते दीपक जी, मुझे Anshfinance से होम लोन (Home Loan) के बारे में जानकारी चाहिए।'
      : 'Hello Deepak ji, I would like to inquire about Home Loan services with Anshfinance.'
  );

  const navLinks = [
    { href: '#home', labelHi: 'होम', labelEn: 'Home' },
    { href: '#about', labelHi: 'हमारे बारे में', labelEn: 'About Us' },
    { href: '#services', labelHi: 'होम लोन', labelEn: 'Services' },
    { href: '#ai-advisor', labelHi: '🤖 AI चैट', labelEn: '🤖 AI Chat' },
    { href: '#how-it-works', labelHi: 'प्रक्रिया', labelEn: 'How It Works' },
    { href: '#documents', labelHi: 'दस्तावेज', labelEn: 'Documents' },
    { href: '#calculator', labelHi: 'EMI कैलकुलेटर', labelEn: 'EMI Calculator' },
    { href: '#why-us', labelHi: 'विशेषताएं', labelEn: 'Why Us' },
    { href: '#contact', labelHi: 'संपर्क करें', labelEn: 'Contact' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-xs">
      {/* Top Notification / Hours Bar */}
      <div className="bg-[#0B192C] text-slate-300 text-xs py-2 px-4 hidden md:block border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-6">
            <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
              <Clock className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'कार्य समय: सुबह 7:00 बजे से रात 10:00 बजे तक' : 'Working Hours: 7:00 AM – 10:00 PM (Daily)'}</span>
            </span>
            <span className="flex items-center gap-1.5 text-slate-300">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
              <span>{BUSINESS_INFO.location}, {BUSINESS_INFO.nearby}, {BUSINESS_INFO.city}</span>
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-slate-300">
              {lang === 'hi' ? 'संचालक:' : 'Advisor:'} <strong className="text-white font-semibold">{BUSINESS_INFO.owner}</strong>
            </span>
            <span className="text-slate-600">|</span>
            <a 
              href={`tel:${BUSINESS_INFO.phone}`} 
              className="flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-semibold transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              {BUSINESS_INFO.phoneFormatted}
            </a>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-3 group" id="nav-brand-logo">
            <div className="w-11 h-11 rounded-xl bg-[#0B192C] text-emerald-400 border border-slate-700 flex items-center justify-center shadow-md group-hover:bg-emerald-600 group-hover:text-white transition-all">
              <Home className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold tracking-tight text-[#0B192C]">
                  Ansh<span className="text-emerald-600">finance</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-200 hidden sm:inline-block">
                  Indore
                </span>
              </div>
              <p className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold leading-none mt-1">
                {lang === 'hi' ? 'होम लोन सलाहकार • दीपक वर्मा' : 'Home Loan Services • Deepak Verma'}
              </p>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="px-3 py-2 rounded-lg text-xs font-bold uppercase tracking-wider text-slate-600 hover:text-emerald-700 hover:bg-slate-100 transition-colors"
              >
                {lang === 'hi' ? link.labelHi : link.labelEn}
              </a>
            ))}
          </nav>

          {/* Action Buttons & Language Switcher */}
          <div className="hidden sm:flex items-center space-x-3">
            {/* Language Toggle Button */}
            <button
              onClick={onToggleLang}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold uppercase tracking-wider rounded-lg border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer"
              title="Change Language"
              id="lang-toggle-btn"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{lang === 'hi' ? 'English' : 'हिंदी'}</span>
            </button>

            {/* AI Assistant Quick Button */}
            <button
              onClick={onOpenAiChat}
              className="flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 transition-colors px-3 py-2 text-xs font-bold uppercase tracking-wider rounded-lg shadow-2xs cursor-pointer group"
              id="nav-ai-chat-btn"
              title="Open AI Home Loan Assistant"
            >
              <Bot className="w-3.5 h-3.5 text-emerald-600 group-hover:scale-110 transition-transform" />
              <span>{lang === 'hi' ? 'AI सहायक' : 'Ask AI'}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            </button>

            {/* Direct Call Button */}
            <a
              href={`tel:${BUSINESS_INFO.phone}`}
              className="flex items-center gap-1.5 bg-[#0B192C] text-white px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg hover:bg-[#1E3A8A] transition-colors shadow-xs"
              id="nav-call-btn"
            >
              <Phone className="w-3.5 h-3.5 fill-current" />
              <span>9826686170</span>
            </a>

            {/* Apply / Enquiry Button */}
            <button
              onClick={onOpenEnquiry}
              className="flex items-center gap-1.5 bg-emerald-600 text-white hover:bg-emerald-700 transition-colors px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg shadow-sm cursor-pointer"
              id="nav-apply-btn"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'आवेदन करें' : 'Apply Now'}</span>
            </button>
          </div>

          {/* Mobile Menu & Language Toggle Button */}
          <div className="flex sm:hidden items-center space-x-2">
            <button
              onClick={onToggleLang}
              className="px-2.5 py-1.5 text-xs font-bold rounded-lg border border-slate-200 bg-slate-50 text-slate-800 uppercase tracking-wider"
            >
              {lang === 'hi' ? 'EN' : 'हिंदी'}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:bg-slate-100 border border-slate-200 cursor-pointer"
              aria-label="Toggle navigation menu"
              id="mobile-menu-toggle"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="sm:hidden bg-white border-t border-slate-200 px-4 pt-4 pb-6 space-y-4 shadow-xl">
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5 text-slate-700">
            <div className="uppercase tracking-wider text-sm font-bold text-[#0B192C]">{BUSINESS_INFO.name} — {BUSINESS_INFO.owner}</div>
            <div className="text-slate-600 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-emerald-600" />
              <span>{BUSINESS_INFO.workingHours[lang]}</span>
            </div>
            <div className="text-slate-600 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              <span>{BUSINESS_INFO.location}, {BUSINESS_INFO.city}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors border border-transparent hover:border-emerald-200"
              >
                {lang === 'hi' ? link.labelHi : link.labelEn}
              </a>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-200 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAiChat();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-800 font-bold text-xs uppercase tracking-wider hover:bg-emerald-100 cursor-pointer shadow-2xs"
            >
              <Bot className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'hi' ? '🤖 24/7 AI लोन सहायक से पूछें' : '🤖 Ask 24/7 AI Loan Advisor'}</span>
            </button>
            <a
              href={`tel:${BUSINESS_INFO.phone}`}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-[#0B192C] text-white font-bold text-xs uppercase tracking-wider shadow-sm"
            >
              <Phone className="w-4 h-4 fill-current" />
              <span>{lang === 'hi' ? 'कॉल करें: 9826686170' : 'Call: 9826686170'}</span>
            </a>
            <a
              href={defaultWaUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 font-bold text-xs uppercase tracking-wider hover:bg-emerald-100"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'hi' ? 'व्हाट्सएप पर बात करें' : 'WhatsApp Us'}</span>
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenEnquiry();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 font-bold text-xs uppercase tracking-widest shadow-sm"
            >
              <FileText className="w-4 h-4" />
              <span>{lang === 'hi' ? 'होम लोन इन्क्वायरी भरें' : 'Apply for Home Loan'}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
