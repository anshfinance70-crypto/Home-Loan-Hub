import { BusinessDetails, ProcessStep, DocumentItem, WhyChooseItem, LoanTypeItem, FaqItem } from '../types';

export const BUSINESS_INFO: BusinessDetails = {
  name: 'Anshfinance',
  category: 'Home Loan Services',
  owner: 'Deepak Verma',
  location: '265-B, Arihant Nagar',
  nearby: 'Near Gommatgiri',
  city: 'Indore',
  state: 'Madhya Pradesh',
  fullAddress: '265-B, Arihant Nagar, Indore, Madhya Pradesh (Near Gommatgiri)',
  workingHours: {
    hi: 'सुबह 7:00 बजे से रात 10:00 बजे तक (प्रतिदिन)',
    en: '7:00 AM to 10:00 PM (All 7 Days)',
    openTime: '07:00 AM',
    closeTime: '10:00 PM',
  },
  phone: '9826686170',
  phoneFormatted: '+91 98266 86170',
  whatsapp: '9826686170',
  whatsappFormatted: '+91 98266 86170',
  email: 'anshfinance70@gmail.com',
  mapsUrl: 'https://www.google.com/maps/search/?api=1&query=265-B+Arihant+Nagar+Indore+Near+Gommatgiri',
  tagline: {
    hi: 'आपके सपनों के घर तक, हमारा साथ।',
    en: 'Your trusted partner to your dream home.',
  },
  subTagline: {
    hi: 'Home Loan की प्रक्रिया को समझने और सही विकल्प तक पहुँचने में सरल और निष्पक्ष सहायता।',
    en: 'Simplifying your home loan journey with transparent guidance & multiple lending options in Indore.',
  },
};

export const BANK_NETWORK_DISCLAIMER = {
  hi: 'हम विभिन्न प्रमुख Banks और Financial Institutions के साथ Home Loan solutions के लिए काम करते हैं।',
  en: 'We work with leading Banks and Financial Institutions to offer suitable Home Loan solutions.',
};

export const REGULATORY_NOTE = {
  hi: 'नोट: Loan approval, ब्याज दर (Interest rate), लोन राशि (Amount) और पात्रता (Eligibility) संबंधित lender (Bank/NBFC) की नीतियों और ग्राहक की प्रोफाइल पर निर्भर करती है।',
  en: 'Note: Loan approval, interest rates, sanctioned amount and eligibility are subject to the policies of the respective lending institution and applicant credit profile.',
};

export const PROCESS_STEPS: ProcessStep[] = [
  {
    step: 1,
    titleHi: '1. Enquiry (संपर्क करें)',
    titleEn: '1. Enquiry & Consultation',
    descHi: 'हमसे Call या WhatsApp (9826686170) पर तुरंत संपर्क करें और अपनी जरूरत बताएं।',
    descEn: 'Contact us via Call or WhatsApp (9826686170) and share your loan requirement.',
    iconName: 'PhoneCall',
    actionTextHi: 'कॉल या व्हाट्सएप करें',
    actionTextEn: 'Call or WhatsApp',
  },
  {
    step: 2,
    titleHi: '2. Basic Details (प्राथमिक जानकारी)',
    titleEn: '2. Basic Details Sharing',
    descHi: 'अपनी basic financial स्थिति और property-related जानकारी हमारे साथ साझा करें।',
    descEn: 'Share basic income details and property requirements for preliminary evaluation.',
    iconName: 'FileSpreadsheet',
  },
  {
    step: 3,
    titleHi: '3. Loan Options (विकल्पों पर चर्चा)',
    titleEn: '3. Loan Options Discussion',
    descHi: 'आपकी जरूरत व प्रोफाइल के अनुसार उपलब्ध विभिन्न Banks/NBFCs के Home Loan options पर चर्चा की जाएगी।',
    descEn: 'We discuss and compare suitable home loan products, tenures and rates across lenders.',
    iconName: 'SlidersHorizontal',
  },
  {
    step: 4,
    titleHi: '4. Application (आवेदन प्रक्रिया)',
    titleEn: '4. Application Submission',
    descHi: 'उचित lender के साथ application form और आवश्यक दस्तावेजों के साथ process आगे बढ़ाया जाएगा।',
    descEn: 'Your home loan file is structured and initiated with the chosen banking partner.',
    iconName: 'Send',
  },
  {
    step: 5,
    titleHi: '5. Bank Process (सत्यापन व मूल्यांकन)',
    titleEn: '5. Bank Verification & Legal',
    descHi: 'Bank/NBFC द्वारा document verification, legal check और property assessment किया जाएगा।',
    descEn: 'The lender conducts verification, credit underwriting, and property legal evaluation.',
    iconName: 'ShieldCheck',
  },
  {
    step: 6,
    titleHi: '6. Loan Decision (स्वीकृति व संवितरण)',
    titleEn: '6. Loan Sanction & Decision',
    descHi: 'Lender की eligibility और policies के अनुसार final approval और संवितरण (disbursement) होगा।',
    descEn: 'Final sanction letter is issued and disbursement is executed according to lender guidelines.',
    iconName: 'CheckCircle2',
  },
];

export const DOCUMENTS_LIST: DocumentItem[] = [
  {
    nameHi: 'Identity Proof (पहचान पत्र)',
    nameEn: 'Identity Proof',
    detailHi: 'PAN Card (अनिवार्य), Aadhaar Card, Passport, या Voter ID Card',
    detailEn: 'PAN Card (Mandatory), Aadhaar Card, Passport, or Voter ID',
    category: 'general',
  },
  {
    nameHi: 'Address Proof (निवास प्रमाण)',
    nameEn: 'Address Proof',
    detailHi: 'Aadhaar Card, बिजली बिल, Voter ID, या पासपोर्ट',
    detailEn: 'Aadhaar Card, Latest Utility Bill, Voter ID, or Passport',
    category: 'general',
  },
  {
    nameHi: 'Salaried: Income Proof (वेतनभोगी आय प्रमाण)',
    nameEn: 'Salaried: Income Documents',
    detailHi: 'पिछले 3 महीने की Salary Slips, 2 साल का Form 16, और Employment Appointment Letter',
    detailEn: 'Latest 3 months salary slips, 2 years Form 16, and employment confirmation',
    category: 'salaried',
  },
  {
    nameHi: 'Self-Employed: Income Proof (व्यवसायी आय प्रमाण)',
    nameEn: 'Self-Employed: Business Financials',
    detailHi: 'पिछले 2 से 3 वर्षों का Income Tax Return (ITR), Computation of Income, P&L, Balance Sheet और GST Certificate',
    detailEn: 'Last 2-3 years ITR with computation, CA certified balance sheet, P&L, GST registration',
    category: 'self_employed',
  },
  {
    nameHi: 'Bank Statements (बैंक विवरण)',
    nameEn: 'Bank Statements',
    detailHi: 'पिछले 6 से 12 महीने का Salary/Business Account Bank Statement (विद सील या e-statement)',
    detailEn: 'Last 6 to 12 months operating bank account statements with narration',
    category: 'general',
  },
  {
    nameHi: 'Property Documents (प्रॉपर्टी दस्तावेज)',
    nameEn: 'Property Related Documents',
    detailHi: 'Allotment Letter / Agreement to Sale, Chain of Title Deeds, स्वीकृत नक्शा (Approved Layout/Map), एवं NOC',
    detailEn: 'Agreement to Sell / Allotment letter, Chain deeds, Approved building map, and relevant NOCs',
    category: 'property',
  },
  {
    nameHi: 'अन्य आवश्यक दस्तावेज (Lender Requirements)',
    nameEn: 'Other Supporting Documents',
    detailHi: 'Passport size photos, पूर्व चालू लोन की विवरण (यदि कोई हो), बैंक चेक (Processing Fee)',
    detailEn: 'Passport size photographs, existing loan sanction letters (if any), processing fee cheque',
    category: 'general',
  },
];

export const WHY_CHOOSE_US: WhyChooseItem[] = [
  {
    id: 'focus',
    titleHi: 'Home Loan Focused Service',
    titleEn: 'Home Loan Focused Expertise',
    descHi: 'हमारा एकमात्र उद्देश्य और विशेषज्ञता केवल Home Loans पर है, जिससे आपको केंद्रित और गहराई से परामर्श मिलता है।',
    descEn: 'Dedicated focus solely on Home Loans, ensuring tailored guidance and expert financial navigation.',
    iconName: 'Home',
  },
  {
    id: 'guidance',
    titleHi: 'Guidance Throughout The Process',
    titleEn: 'End-to-End Handholding',
    descHi: 'शुरुआती पूछताछ से लेकर दस्तावेज तैयार करने और बैंक संवितरण तक कदम-दर-कदम पूरा साथ।',
    descEn: 'Personalized support at every stage — from application filing to document submission and sanctioning.',
    iconName: 'Compass',
  },
  {
    id: 'options',
    titleHi: 'Multiple Lender Options',
    titleEn: 'Multiple Bank & NBFC Options',
    descHi: 'विभिन्न प्रमुख सरकारी, प्राइवेट बैंकों एवं प्रतिष्ठित NBFCs के साथ काम कर आपकी प्रोफाइल अनुसार सही विकल्प।',
    descEn: 'Access solutions across leading public sector, private banks, and reputed housing finance NBFCs.',
    iconName: 'Building2',
  },
  {
    id: 'communication',
    titleHi: 'Easy Call & WhatsApp Communication',
    titleEn: 'Fast Call & WhatsApp Support',
    descHi: 'सीधे दीपक वर्मा जी से 9826686170 पर कॉल या व्हाट्सएप से बिना किसी जटिलता के तुरंत बातचीत।',
    descEn: 'Direct, hassle-free communication directly via Call or WhatsApp on 9826686170 anytime.',
    iconName: 'MessageSquare',
  },
  {
    id: 'hours',
    titleHi: 'Convenient Working Hours',
    titleEn: 'Extended Working Hours',
    descHi: 'सुबह 7:00 बजे से रात 10:00 बजे तक सेवा उपलब्ध, ताकि आप अपने व्यस्त शेड्यूल के अनुसार बात कर सकें।',
    descEn: 'Available daily from 7:00 AM to 10:00 PM, allowing flexible discussions around your work hours.',
    iconName: 'Clock',
  },
  {
    id: 'local',
    titleHi: 'Local Service In Indore',
    titleEn: 'Trusted Local Service in Indore',
    descHi: '265-B अरिहंत नगर (गोम्मटगिरि के पास), इंदौर स्थित स्थानीय कार्यालय, व्यक्तिगत भरोसेमंद सेवा हेतु।',
    descEn: 'Physical local presence at 265-B Arihant Nagar, Indore (Near Gommatgiri) for face-to-face trust.',
    iconName: 'MapPin',
  },
];

export const LOAN_TYPES: LoanTypeItem[] = [
  {
    id: 'purchase',
    titleHi: 'नया घर / फ्लैट खरीद लोन',
    titleEn: 'Home Purchase Loan',
    descHi: 'रेडी-टू-मूव या अंडर-कंस्ट्रक्शन मकान, फ्लैट या रो-हाउस खरीदने के लिए उचित लोन मार्गदर्शन।',
    descEn: 'Financing assistance for purchasing new or resale residential flats, row houses, or bungalows.',
    tagHi: 'सर्वाधिक लोकप्रिय',
    tagEn: 'Most Popular',
    icon: 'Key',
  },
  {
    id: 'construction',
    titleHi: 'मकान निर्माण लोन',
    titleEn: 'Home Construction Loan',
    descHi: 'यदि आपके पास पहले से प्लॉट है, तो उस पर अपने मनपसंद मकान के निर्माण हेतु चरणबद्ध लोन सहायता।',
    descEn: 'Stage-wise disbursement guidance to construct your custom home on your owned residential plot.',
    tagHi: 'प्लॉट धारकों हेतु',
    tagEn: 'For Plot Owners',
    icon: 'Hammer',
  },
  {
    id: 'plot_plus_construction',
    titleHi: 'प्लॉट + निर्माण लोन',
    titleEn: 'Plot + Construction Loan',
    descHi: 'प्लॉट खरीदने और उसी पर निर्धारित समय में मकान निर्माण दोनों के लिए संयुक्त लोन प्रक्रिया।',
    descEn: 'Composite home loans covering both residential land acquisition and subsequent house building.',
    tagHi: 'कम्पोजिट लोन',
    tagEn: 'Composite Loan',
    icon: 'Layers',
  },
  {
    id: 'renovation',
    titleHi: 'घर नवीनीकरण व विस्तार',
    titleEn: 'Home Extension & Renovation',
    descHi: 'अपने मौजूदा घर में अतिरिक्त कमरा, मंजिल, नया इंटीरियर या मरम्मत कार्य कराने हेतु वित्तीय विकल्प।',
    descEn: 'Financing for adding rooms, floors, structural repairs, or modern interior upgrades to your house.',
    tagHi: 'अपग्रेडेशन',
    tagEn: 'Upgrade & Expand',
    icon: 'Paintbrush',
  },
  {
    id: 'balance_transfer',
    titleHi: 'होम लोन बैलेंस ट्रांसफर व टॉप-अप',
    titleEn: 'Balance Transfer & Top-Up',
    descHi: 'वर्तमान महंगे लोन को कम ब्याज दर वाले बैंक में ट्रांसफर कराएं और आवश्यक अतिरिक्त टॉप-अप राशि पाएं।',
    descEn: 'Transfer your high-interest home loan to lower rate institutions with optional top-up funds.',
    tagHi: 'बचत योजना',
    tagEn: 'Save Interest',
    icon: 'ArrowLeftRight',
  },
];

export const PROMINENT_BANKS = [
  { name: 'State Bank of India', tag: 'Public Sector Leader' },
  { name: 'HDFC Bank', tag: 'Private Banking Leader' },
  { name: 'ICICI Bank', tag: 'Quick Processing' },
  { name: 'Bank of Baroda', tag: 'Competitive Rates' },
  { name: 'Punjab National Bank', tag: 'Nationalized Bank' },
  { name: 'Axis Bank', tag: 'Flexible Solutions' },
  { name: 'LIC Housing Finance', tag: 'Housing Finance Co.' },
  { name: 'PNB Housing', tag: 'Specialized Housing' },
  { name: 'Tata Capital', tag: 'Reputed NBFC' },
  { name: 'Bajaj Housing Finance', tag: 'Fast Digital Approvals' },
];

export const FAQ_ITEMS: FaqItem[] = [
  {
    qHi: 'Anshfinance किस प्रकार की सहायता प्रदान करता है?',
    qEn: 'What kind of assistance does Anshfinance provide?',
    aHi: 'Anshfinance ग्राहकों को होम लोन की संपूर्ण प्रक्रिया में सहायता करता है — जैसे सही बैंक/NBFC का चुनाव, ब्याज दरों की तुलना, आवश्यक दस्तावेजों की जांच, फाइल तैयार करना और बैंक अधिकारियों के साथ समन्वय स्थापित करना।',
    aEn: 'Anshfinance assists clients throughout the complete home loan journey — including comparing lender options, preparing eligible documentation, coordinating with bank underwriting teams, and tracking files till approval.',
  },
  {
    qHi: 'क्या होम लोन की स्वीकृति की गारंटी होती है?',
    qEn: 'Is home loan approval guaranteed?',
    aHi: 'नहीं, किसी भी लोन की स्वीकृति, ब्याज दर, और राशि पूरी तरह से संबंधित बैंक/NBFC की पॉलिसी और आपकी वित्तीय व संपत्ति पात्रता पर निर्भर करती है। Anshfinance का काम आपकी फाइल को सबसे मजबूत तरीके से सही बैंक तक पहुंचाना है ताकि स्वीकृति की संभावना बेहतर हो सके।',
    aEn: 'No genuine loan consultant guarantees 100% approval. Sanctioning, interest rate and loan amount strictly depend on bank/NBFC credit policies and the applicant’s profile. Our role is to optimize your application and match you with the right lender.',
  },
  {
    qHi: 'Anshfinance से संपर्क करने का समय क्या है?',
    qEn: 'What are the working hours to reach Anshfinance?',
    aHi: 'आप सुबह 7:00 बजे से रात 10:00 बजे तक (सप्ताह के सातों दिन) दीपक वर्मा जी से 9826686170 पर कॉल या व्हाट्सएप के जरिए संपर्क कर सकते हैं।',
    aEn: 'You can contact Deepak Verma directly via Call or WhatsApp at 9826686170 daily between 7:00 AM and 10:00 PM.',
  },
  {
    qHi: 'इंदौर में आपका कार्यालय कहाँ स्थित है?',
    qEn: 'Where is your office located in Indore?',
    aHi: 'हमारा कार्यालय 265-B, अरिहंत नगर, गोम्मटगिरि के पास, इंदौर (मध्य प्रदेश) में स्थित है। आप व्यक्तिगत रूप से मिलकर भी लोन से जुड़े कागजात व विकल्पों पर चर्चा कर सकते हैं।',
    aEn: 'Our office is located at 265-B, Arihant Nagar, Near Gommatgiri, Indore, Madhya Pradesh. In-person consultations are warmly welcome by prior appointment or call.',
  },
  {
    qHi: 'होम लोन के लिए न्यूनतम कितने सिबिल (CIBIL) स्कोर की आवश्यकता होती है?',
    qEn: 'What is the ideal CIBIL score required for a home loan?',
    aHi: 'आमतौर पर 750 या उससे अधिक का क्रेडिट स्कोर सबसे अच्छी ब्याज दरों और आसान स्वीकृति के लिए आदर्श माना जाता है। हालांकि कुछ बैंक 650-700 स्कोर पर भी उपयुक्त नियमों के तहत विचार करते हैं।',
    aEn: 'A CIBIL credit score of 750 and above typically secures the lowest interest rates and fastest sanctions. However, several lenders evaluate profiles in the 650-749 range with specific norms.',
  },
];
