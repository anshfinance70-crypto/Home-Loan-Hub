import { CalculationResult } from '../types';

export function formatIndianCurrency(amount: number, compact: boolean = false): string {
  if (isNaN(amount) || amount === 0) return '₹0';

  if (compact) {
    if (amount >= 10000000) {
      const cr = amount / 10000000;
      return `₹${cr % 1 === 0 ? cr.toFixed(0) : cr.toFixed(2)} Cr`;
    }
    if (amount >= 100000) {
      const lakh = amount / 100000;
      return `₹${lakh % 1 === 0 ? lakh.toFixed(0) : lakh.toFixed(2)} Lakh`;
    }
    if (amount >= 1000) {
      const k = amount / 1000;
      return `₹${k % 1 === 0 ? k.toFixed(0) : k.toFixed(1)}k`;
    }
  }

  // Standard Indian comma separator: 12,34,567
  const parts = Math.round(amount).toString().split('.');
  let lastThree = parts[0].substring(parts[0].length - 3);
  const otherNumbers = parts[0].substring(0, parts[0].length - 3);
  if (otherNumbers !== '') {
    lastThree = ',' + lastThree;
  }
  const res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;
  return `₹${res}`;
}

export function calculateEmi(principal: number, annualRate: number, tenureYears: number): CalculationResult {
  if (!principal || principal <= 0 || !tenureYears || tenureYears <= 0) {
    return {
      monthlyEmi: 0,
      principalAmount: principal || 0,
      totalInterest: 0,
      totalPayment: principal || 0,
      principalPercent: 100,
      interestPercent: 0,
    };
  }

  const monthlyRate = annualRate / 12 / 100;
  const numberOfMonths = tenureYears * 12;

  let monthlyEmi = 0;
  if (monthlyRate === 0) {
    monthlyEmi = principal / numberOfMonths;
  } else {
    const rateFactor = Math.pow(1 + monthlyRate, numberOfMonths);
    monthlyEmi = (principal * monthlyRate * rateFactor) / (rateFactor - 1);
  }

  const totalPayment = monthlyEmi * numberOfMonths;
  const totalInterest = Math.max(0, totalPayment - principal);

  const total = principal + totalInterest;
  const principalPercent = total > 0 ? Math.round((principal / total) * 100) : 50;
  const interestPercent = 100 - principalPercent;

  return {
    monthlyEmi: Math.round(monthlyEmi),
    principalAmount: Math.round(principal),
    totalInterest: Math.round(totalInterest),
    totalPayment: Math.round(totalPayment),
    principalPercent,
    interestPercent,
  };
}

export function createWhatsAppUrl(phone: string, message: string): string {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const targetPhone = cleanPhone.startsWith('91') ? cleanPhone : `91${cleanPhone}`;
  return `https://wa.me/${targetPhone}?text=${encodeURIComponent(message)}`;
}
