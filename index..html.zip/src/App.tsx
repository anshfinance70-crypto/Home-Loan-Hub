import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutUs } from './components/AboutUs';
import { ServicesSection } from './components/ServicesSection';
import { AiChatSection } from './components/AiChatSection';
import { HowItWorks } from './components/HowItWorks';
import { DocumentsSection } from './components/DocumentsSection';
import { EmiCalculator } from './components/EmiCalculator';
import { WhyChooseUs } from './components/WhyChooseUs';
import { ContactSection } from './components/ContactSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';
import { EnquiryModal } from './components/EnquiryModal';
import { AiChatAssistant } from './components/AiChatAssistant';
import { Language } from './types';

export default function App() {
  const [lang, setLang] = useState<Language>('hi');
  const [isEnquiryModalOpen, setIsEnquiryModalOpen] = useState<boolean>(false);
  const [isAiChatOpen, setIsAiChatOpen] = useState<boolean>(false);
  const [aiChatInitialQuery, setAiChatInitialQuery] = useState<string>('');

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'hi' ? 'en' : 'hi'));
  };

  const openEnquiry = () => {
    setIsEnquiryModalOpen(true);
  };

  const closeEnquiry = () => {
    setIsEnquiryModalOpen(false);
  };

  const openAiChat = (query?: string) => {
    if (query) {
      setAiChatInitialQuery(query);
    }
    setIsAiChatOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-slate-900 font-sans selection:bg-emerald-600 selection:text-white">
      {/* Top Navigation */}
      <Navbar 
        lang={lang} 
        onToggleLang={toggleLanguage} 
        onOpenEnquiry={openEnquiry} 
        onOpenAiChat={() => openAiChat()}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Hero Section with Brand Tagline & Quick CTAs */}
        <Hero 
          lang={lang} 
          onOpenEnquiry={openEnquiry} 
          onOpenAiChat={() => openAiChat()}
        />

        {/* 2. About Us - Deepak Verma & Indore Location */}
        <AboutUs 
          lang={lang} 
        />

        {/* 3. Main Service: Home Loan & Bank Network */}
        <ServicesSection 
          lang={lang} 
          onOpenEnquiry={openEnquiry} 
        />

        {/* 4. Dedicated 24/7 AI Home Loan Information & Query Section */}
        <AiChatSection
          lang={lang}
          onOpenChatWithQuery={(q) => openAiChat(q)}
        />

        {/* 5. How It Works: 6-Step Loan Process */}
        <HowItWorks 
          lang={lang} 
          onOpenEnquiry={openEnquiry} 
        />

        {/* 6. Required Documents Checklist */}
        <DocumentsSection 
          lang={lang} 
        />

        {/* 7. Interactive EMI Calculator */}
        <EmiCalculator 
          lang={lang} 
          onOpenEnquiry={openEnquiry} 
        />

        {/* 8. Why Choose Anshfinance? */}
        <WhyChooseUs 
          lang={lang} 
        />

        {/* 9. Contact Us: Contact Card & Quick Enquiry Form */}
        <ContactSection 
          lang={lang} 
        />

        {/* 10. FAQs */}
        <FaqSection 
          lang={lang} 
        />
      </main>

      {/* Footer */}
      <Footer 
        lang={lang} 
      />

      {/* Floating Call & WhatsApp Buttons */}
      <FloatingActions 
        lang={lang} 
        onOpenEnquiry={openEnquiry} 
        onOpenAiChat={() => openAiChat()}
      />

      {/* Interactive 24/7 AI Home Loan Chat Assistant Widget */}
      <AiChatAssistant
        lang={lang}
        isOpen={isAiChatOpen}
        onClose={() => setIsAiChatOpen(false)}
        onOpen={() => setIsAiChatOpen(true)}
        initialQuery={aiChatInitialQuery}
      />

      {/* Enquiry Modal */}
      <EnquiryModal 
        isOpen={isEnquiryModalOpen} 
        onClose={closeEnquiry} 
        lang={lang} 
      />
    </div>
  );
}

