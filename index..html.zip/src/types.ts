export type Language = 'hi' | 'en';

export interface BusinessDetails {
  name: string;
  category: string;
  owner: string;
  location: string;
  nearby: string;
  city: string;
  state: string;
  fullAddress: string;
  workingHours: {
    hi: string;
    en: string;
    openTime: string;
    closeTime: string;
  };
  phone: string;
  phoneFormatted: string;
  whatsapp: string;
  whatsappFormatted: string;
  email: string;
  mapsUrl: string;
  tagline: {
    hi: string;
    en: string;
  };
  subTagline: {
    hi: string;
    en: string;
  };
}

export interface LoanEnquiryForm {
  name: string;
  phone: string;
  loanAmount: string;
  loanPurpose: string;
  employmentType: string;
  preferredCallTime: string;
  message: string;
}

export interface CalculationResult {
  monthlyEmi: number;
  principalAmount: number;
  totalInterest: number;
  totalPayment: number;
  principalPercent: number;
  interestPercent: number;
}

export interface ProcessStep {
  step: number;
  titleHi: string;
  titleEn: string;
  descHi: string;
  descEn: string;
  iconName: string;
  actionTextHi?: string;
  actionTextEn?: string;
}

export interface DocumentItem {
  nameHi: string;
  nameEn: string;
  detailHi: string;
  detailEn: string;
  category: 'salaried' | 'self_employed' | 'property' | 'general';
}

export interface WhyChooseItem {
  id: string;
  titleHi: string;
  titleEn: string;
  descHi: string;
  descEn: string;
  iconName: string;
}

export interface LoanTypeItem {
  id: string;
  titleHi: string;
  titleEn: string;
  descHi: string;
  descEn: string;
  tagHi: string;
  tagEn: string;
  icon: string;
}

export interface FaqItem {
  qHi: string;
  qEn: string;
  aHi: string;
  aEn: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}
