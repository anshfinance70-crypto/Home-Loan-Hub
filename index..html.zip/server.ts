import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;

const SYSTEM_INSTRUCTION = `You are 'Anshfinance AI Sahayak' (अंशफाइनेंस एआई ऋण सहायक), the official friendly and knowledgeable AI Home Loan Assistant for Anshfinance in Indore, Madhya Pradesh.

Director / Lead Advisor: Deepak Verma (दीपक वर्मा)
Contact: +91 9826686170
Email: anshfinance70@gmail.com
Office Address: 265-B, Arihant Nagar, Near Gommatgiri / Airport Road, Indore (M.P.) - 452005
Operating Hours: 7:00 AM to 10:00 PM (All 7 Days)

Primary Services:
1. New Home Loan (नया गृह ऋण) - Flats, Row Houses, Independent Houses, Bungalows, Villas.
2. Plot + Construction Loan (भूखंड क्रय एवं गृह निर्माण ऋण) - Buying land and constructing home together.
3. Home Construction Loan (खुद के प्लॉट पर निर्माण ऋण) - For already owned land/plot with approved map, diversion & T&CP/RERA.
4. Home Renovation / Improvement Loan (गृह नवीनीकरण एवं विस्तार ऋण) - Repair, remodeling, additional floor/room.
5. Home Loan Balance Transfer & Top-Up (होम लोन बैलेंस ट्रांसफर + टॉप-अप) - Transfer existing high-interest loan to lower rates + extra liquidity for personal/business needs.
6. Loan Against Property (LAP / मॉर्गेज लोन) - Mortgage of residential or commercial property for funds.

Bank & NBFC Network:
Anshfinance coordinates with India's leading Public Banks (SBI, Bank of Baroda, PNB), Top Private Banks (HDFC Bank, ICICI Bank, Axis Bank, Kotak), and Reputed Housing Finance Companies (LIC HFL, PNB Housing, Tata Capital, Bajaj Housing Finance) to match each applicant's profile to the lowest possible interest rate and maximum loan eligibility.

Key Knowledge Base:
- Standard Interest Rates: ~8.40% to 9.25% p.a. (floating rates based on RBI Repo Rate & applicant CIBIL).
- Loan Tenure: Up to 30 years (360 months) depending on applicant age at maturity (up to 65-70 yrs).
- LTV (Loan-to-Value): Up to 75% to 90% of property market/registry value.
- CIBIL Score: 750+ receives prime rates. 700-749 is standard. If below 700, NBFCs or adding a credit-worthy co-applicant helps secure approval.
- Salaried Requirements: Min salary ₹20k-25k/mo, 3 months salary slips, 6 months bank statement, Form 16 / 2 years ITR, employer ID, Aadhaar, PAN.
- Self-Employed / Business Requirements: 2-3 years ITR with computation of income, balance sheet & P&L (CA certified/audited if applicable), 1-year bank statements (current + savings), GST/Gumasta registration, business address proof.
- Property Papers: Registered sale deed / chain deeds (13 to 30 years), Approved map / building permission from Indore Municipal Corporation (IMC) or Gram Panchayat, Diversion order / Nazul NOC, T&CP or RERA sanction, recent property tax / diversion receipts.
- Co-Applicant Benefit: Adding spouse, parent, or earning child increases total sanctioned loan amount and improves approval probability.

Rules for Responses:
- Match the user's language: If user writes in Hindi, reply in clear, polite Hindi (Devanagari script). If English, reply in polished English. If Hinglish, reply in conversational, easy-to-understand Hinglish.
- Be structured: Use clear headings, bullet points, bold key terms, and numbered steps.
- Realistic & Honest: Avoid making false 100% guarantees. Explain that exact loan sanction depends on bank policy, CIBIL, property legal valuation, and banking records.
- Local Indore Touch: Mention local Indore service (doorstep document pickup, Arihant Nagar, Airport Road, Super Corridor, Bypass, Vijay Nagar) and Deepak Verma's direct number (9826686170).
- When appropriate, advise users that they can call or WhatsApp Deepak Verma on 9826686170 for instant profile review or file preparation.`;

async function startServer() {
  const app = express();

  app.use(express.json());

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'Anshfinance Home Loan API' });
  });

  // AI Chat endpoint
  app.post('/api/chat', async (req, res) => {
    try {
      const { messages, lang = 'hi' } = req.body;

      if (!messages || !Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: 'Messages array is required' });
      }

      const apiKey = process.env.GEMINI_API_KEY;

      // If Gemini API Key is present, call @google/genai with gemini-3.7-flash
      if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
        try {
          const ai = new GoogleGenAI({
            apiKey,
            httpOptions: {
              headers: {
                'User-Agent': 'aistudio-build',
              },
            },
          });

          // Format contents array for Gemini SDK
          const contents = messages.map((m: { role: string; text: string }) => ({
            role: m.role === 'user' ? 'user' : 'model',
            parts: [{ text: m.text }],
          }));

          const response = await ai.models.generateContent({
            model: 'gemini-3.7-flash',
            contents,
            config: {
              systemInstruction: SYSTEM_INSTRUCTION,
              temperature: 0.7,
            },
          });

          const replyText = response.text || (lang === 'hi' 
            ? 'नमस्ते! मुझे आपकी सहायता करने में प्रसन्नता होगी। कृपया अपना होम लोन प्रश्न पुनः पूछें या दीपक जी से 9826686170 पर संपर्क करें।' 
            : 'Hello! I am happy to assist you with Home Loan queries. Please rephrase or contact Deepak Verma directly at 9826686170.');

          return res.json({ reply: replyText });
        } catch (apiErr: any) {
          console.error('Gemini API execution error:', apiErr);
          // Fallback to knowledge response if API quota/transient error occurs
        }
      }

      // Intelligent Fallback Knowledge Engine (if no API key configured or fallback triggered)
      const lastUserMsg = messages[messages.length - 1]?.text?.toLowerCase() || '';
      const fallbackReply = getFallbackHomeLoanResponse(lastUserMsg, lang);

      return res.json({ reply: fallbackReply });
    } catch (err: any) {
      console.error('Error in /api/chat:', err);
      return res.status(500).json({ 
        error: 'Failed to process home loan chat query', 
        details: err?.message || 'Unknown server error' 
      });
    }
  });

  // Vite middleware in dev, static files in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Anshfinance Server running on http://localhost:${PORT}`);
  });
}

// Comprehensive local knowledge base for offline/fallback scenarios
function getFallbackHomeLoanResponse(query: string, lang: 'hi' | 'en'): string {
  const isHi = lang === 'hi' || /[अ-ह]/.test(query);

  if (query.includes('document') || query.includes('दस्तावेज') || query.includes('कागजात') || query.includes('paper')) {
    return isHi
      ? `📋 **होम लोन के आवश्यक दस्तावेज़ (Checklist):**

**1. सामान्य पहचान व निवास प्रमाण (KYC):**
• आधार कार्ड एवं पैन कार्ड (अनिवार्य)
• बिजली बिल / पासपोर्ट / वोटर आईडी (स्थायी पता प्रमाण)
• 3 पासपोर्ट साइज फोटो

**2. वेतनभोगी (Salaried) आवेदकों के लिए:**
• पिछले 3 माह की सैलरी स्लिप (Salary Slips)
• पिछले 6 माह का बैंक स्टेटमेंट (सैलरी क्रेडिट खाता)
• फॉर्म-16 (Form 16) एवं पिछले 2 वर्षों का ITR
• कंपनी पहचान पत्र (Company ID Card)

**3. व्यापारी / स्वरोजगार (Self-Employed) के लिए:**
• पिछले 2-3 वर्षों का ITR (कम्प्यूटेशन, P&L व बैलेंस शीट सहित)
• 12 माह का चालू खाता (Current Account) बैंक स्टेटमेंट
• व्यापार प्रमाण (GST रिटर्न, गुमाश्ता / MSME Udyam प्रमाण पत्र)

**4. संपत्ति के दस्तावेज़ (Property Papers):**
• रजिस्ट्री की प्रति (Sale Deed) व पूर्व चेन डीड्स (13-30 वर्ष)
• नगर निगम / ग्राम पंचायत से स्वीकृत नक्शा (Building Map)
• डायवर्सन आदेश (Diversion Receipt) व टीएंडसीपी/रेरा अनुमति
• हालिया संपत्ति कर (Property Tax) रसीद

💡 **इंदौर में फ़ाइल तैयार कराने या निःशुल्क दस्तावेज़ जांच के लिए:**
दीपक वर्मा (Anshfinance) से सीधे **9826686170** पर संपर्क करें या कार्यालय (265-B, अरिहंत नगर, इंदौर) पधारें।`
      : `📋 **Required Documents for Home Loan:**

**1. General KYC:**
• Aadhaar Card & PAN Card (Mandatory)
• Electricity Bill / Passport (Address Proof)
• 3 Passport-size Photographs

**2. For Salaried Applicants:**
• Last 3 months Salary Slips
• Last 6 months Bank Account Statement (Salary credit)
• Form 16 and 2 years ITR
• Official Employee ID Card

**3. For Self-Employed / Business:**
• Last 2-3 years ITR with Computation, Balance Sheet & P&L
• 12 months Bank Statement (Current & Savings accounts)
• Business Proof: GST Certificate, Udyam / Gumasta Registration

**4. Property Documents:**
• Title Deed (Registry copy) & previous link chain deeds
• Approved Building Plan / Map sanction
• Diversion order & T&CP / RERA clearance
• Latest Property Tax receipts

💡 **For file preparation & personalized advice in Indore:**
Call Deepak Verma directly at **+91 9826686170** or visit 265-B Arihant Nagar, Indore.`;
  }

  if (query.includes('eligib') || query.includes('पात्रता') || query.includes('salary') || query.includes('income') || query.includes('cibil') || query.includes('सिबिल')) {
    return isHi
      ? `📊 **होम लोन पात्रता (Eligibility) एवं CIBIL स्कोर नियम:**

**1. मुख्य पात्रता मानक:**
• **आयु:** 21 वर्ष से 65 वर्ष (लोन परिपक्वता तक)
• **वेतनभोगी (Salaried):** न्यूनतम मासिक आय ₹20,000 - ₹25,000। कम से कम 1 वर्ष का कार्य अनुभव।
• **व्यापारी (Business):** न्यूनतम 2-3 वर्षों का सक्रिय व्यापार व लगातार शुद्ध आय ITR में दर्ज।

**2. CIBIL स्कोर की भूमिका:**
• **750 और अधिक:** उत्कृष्ट (Excellent) — न्यूनतम ब्याज दर (लगभग 8.40% - 8.50%) व त्वरित स्वीकृति।
• **700 से 749:** अच्छा (Good) — मानक ब्याज दरों पर आसानी से ऋण मिल जाता है।
• **650 से 699:** मध्यम — कुछ चुनिंदा हाउसिंग फाइनेंस कंपनियों (NBFCs) से स्वीकृति संभव है।

**3. पात्रता बढ़ाने का उपाय (Pro-Tip):**
यदि आपकी व्यक्तिगत आय अनुसार आवश्यक लोन नहीं मिल पा रहा है, तो पत्नी/पति, माता-पिता या कामकाजी पुत्र/पुत्री को **सह-आवेदक (Co-Applicant)** बनाकर संयुक्त आय के आधार पर अधिक लोन स्वीकृत कराया जा सकता है।

📞 अपनी सटीक लोन पात्रता निशुल्क जांचने हेतु **दीपक वर्मा (Anshfinance): 9826686170** पर कॉल करें।`
      : `📊 **Home Loan Eligibility & CIBIL Score Criteria:**

**1. Basic Criteria:**
• **Age:** 21 to 65 years (at loan maturity)
• **Salaried:** Min. monthly in-hand salary of ₹20,000 - ₹25,000 with at least 1 year job stability.
• **Self-Employed:** Minimum 2-3 years operational track record with consistent taxable profits in ITR.

**2. CIBIL Score Benchmarks:**
• **750+ (Prime):** Best available interest rates (~8.40% - 8.50%) and fastest sanction.
• **700 - 749 (Standard):** Eligible with all major public and private banks.
• **Under 700:** Requires careful bank/NBFC matching or co-applicant backing.

**3. How to Boost Eligibility:**
Add an earning spouse, parent, or child as a **Co-Applicant** to combine household income and qualify for a significantly higher loan amount.

📞 For a free eligibility review in Indore, contact **Deepak Verma at +91 9826686170**.`;
  }

  if (query.includes('interest') || query.includes('rate') || query.includes('ब्याज') || query.includes('दर') || query.includes('percent')) {
    return isHi
      ? `💰 **वर्तमान होम लोन ब्याज दरें (Current Interest Rates - 2026):**

• **प्राइम बैंक दरें (SBI, HDFC, Bank of Baroda, ICICI):**
  लगभग **8.40% से 8.95% वार्षिक** (750+ CIBIL स्कोर वाले आवेदकों हेतु)।
• **हाउसिंग फाइनेंस कंपनियां (LIC HFL, PNB Housing, Tata Capital):**
  लगभग **8.60% से 9.40% वार्षिक**।
• **फ्लोटिंग बनाम फिक्स्ड दर:**
  वर्तमान में 95% होम लोन **फ्लोटिंग ब्याज दर (Floating Rate)** पर होते हैं, जो आरबीआई के रेपो रेट से जुड़े होते हैं। फ्लोटिंग लोन में प्री-पेमेंट या फोरक्लोजर पर कोई पेनल्टी नहीं लगती।
• **ऋण अवधि (Tenure):**
  1 वर्ष से 30 वर्ष तक चुन सकते हैं। अधिक अवधि से मासिक ईएमआई कम हो जाती है।

💡 **Anshfinance कैसे मदद करता है?**
हम आपके प्रोफाइल अनुसार विभिन्न बैंकों के ऑफर्स की तुलना करके आपको सबसे कम प्रोसेसिंग फीस और न्यूनतम ब्याज दर दिलाने में मार्गदर्शन करते हैं।

सीधे कॉल करें: **दीपक वर्मा - 9826686170** (अरिहंत नगर, इंदौर)।`
      : `💰 **Current Home Loan Interest Rates (2026 Trends):**

• **Top Public & Private Banks (SBI, HDFC, BoB, ICICI):**
  Approximately **8.40% to 8.95% p.a.** for applicants with CIBIL > 750.
• **Reputed Housing Finance Companies (LIC HFL, PNB Housing, etc.):**
  Approximately **8.60% to 9.40% p.a.**
• **Floating vs Fixed Rates:**
  Over 95% of home loans in India are floating-rate loans linked to the RBI repo rate. Floating loans offer the distinct benefit of ZERO foreclosure or pre-payment penalty.
• **Tenure Flexibility:**
  Repayment tenure ranges from 1 to 30 years.

💡 **Anshfinance Advantage:**
We negotiate and compare loan offers across top banks to fetch you the lowest available rate and minimal processing charges.

Contact **Deepak Verma: +91 9826686170** (Arihant Nagar, Indore).`;
  }

  if (query.includes('plot') || query.includes('construction') || query.includes('निर्माण') || query.includes('प्लॉट') || query.includes('जमीन')) {
    return isHi
      ? `🏗️ **प्लॉट क्रय एवं गृह निर्माण लोन (Plot + Construction Loan):**

Anshfinance इंदौर में खुद के प्लॉट पर मकान निर्माण या नया प्लॉट खरीदकर उस पर घर बनाने के लिए विशेष मार्गदर्शन प्रदान करता है:

**1. लोन के प्रकार:**
• **प्लॉट + कंस्ट्रक्शन लोन:** जब आप बैंक से जमीन खरीदने और उसी पर मकान बनाने दोनों का संयुक्त लोन लेते हैं।
• **होम कंस्ट्रक्शन लोन:** जब प्लॉट पहले से आपके नाम रजिस्टर्ड है और केवल मकान निर्माण के लिए फंड्स चाहिए।

**2. आवश्यक अनुमतियां (Permissions Required):**
• नगर निगम (IMC) या सक्षम ग्राम पंचायत से **स्वीकृत नक्शा (Sanctioned Map)**
• सक्षम इंजीनियर / आर्किटेक्ट द्वारा तैयार **निर्माण लागत अनुमान (Estimate & BOQ)**
• जमीन का **डायवर्सन (Diversion Order)** एवं टीएंडसीपी (T&CP) अथवा रेरा (RERA) लेआउट
• पूर्व रजिस्ट्री व सर्च रिपोर्ट (13-30 वर्ष)

**3. भुगतान की पद्धति (Disbursement Stages):**
कंस्ट्रक्शन लोन एक साथ पूरा नहीं आता, बल्कि निर्माण कार्य के चरणों (Plinth Level, Slab Casting, Brickwork, Finishing) के अनुसार 3-5 किश्तों में बैंक द्वारा रिलीज किया जाता है।

📞 विस्तृत मार्गदर्शन हेतु संपर्क करें: **दीपक वर्मा (Anshfinance) — 9826686170**`
      : `🏗️ **Plot Purchase & Home Construction Loan:**

Anshfinance offers specialized end-to-end guidance for building your own home in Indore:

**1. Loan Options:**
• **Composite Loan (Plot + Construction):** Financing both the purchase of a residential plot and the house construction together.
• **Pure Construction Loan:** For applicants who already own the plot and require funding for building the structure.

**2. Key Technical Prerequisites:**
• Sanctioned Building Plan / Map from Indore Municipal Corporation (IMC) or Gram Panchayat.
• Detailed Cost Estimate & Architect Valuation Report (BOQ).
• Land Diversion Certificate and T&CP / RERA approved layout.
• Complete 13-30 years legal search and chain deed scrutiny.

**3. Staged Disbursement:**
Funds are released in tranches corresponding to physical construction progress (Plinth level -> Ground Floor Slab -> First Floor -> Finishing).

📞 For site visit or file consultation in Indore: Contact **Deepak Verma at +91 9826686170**.`;
  }

  if (query.includes('transfer') || query.includes('ट्रांसफर') || query.includes('top up') || query.includes('टॉप अप')) {
    return isHi
      ? `🔄 **होम लोन बैलेंस ट्रांसफर (Balance Transfer) और टॉप-अप:**

यदि आपका मौजूदा होम लोन किसी अन्य बैंक या NBFC में अधिक ब्याज दर (जैसे 9.5% या 10%+) पर चल रहा है, तो आप Anshfinance की सहायता से:

1. **कम ब्याज दर पर ट्रांसफर:** अपने लोन को किसी प्रमुख बैंक में लगभग 8.40% - 8.65% की कम दर पर ट्रांसफर कराकर हर महीने हजारों रुपये की EMI बचा सकते हैं।
2. **टॉप-अप लोन (Top-Up Loan):** बैलेंस ट्रांसफर के साथ ही घर के रेनोवेशन, बिज़नेस विस्तार या निजी खर्चों के लिए कम ब्याज दर पर अतिरिक्त नकद राशि प्राप्त कर सकते हैं।
3. **शून्य भागदौड़:** फोरक्लोजर लेटर, लिस्ट ऑफ डॉक्युमेंट्स (LOD) प्राप्त करने से लेकर नए बैंक में चेक जारी करवाने तक की पूरी प्रक्रिया Anshfinance द्वारा सुगम बनाई जाती है।

📞 आज ही अपनी वर्तमान ब्याज दर व ईएमआई की बचत जानने के लिए **दीपक वर्मा: 9826686170** पर कॉल करें!`
      : `🔄 **Home Loan Balance Transfer & Top-Up:**

If your existing home loan is running at a higher interest rate (e.g. 9.5% or 10%+), Anshfinance helps you:

1. **Transfer at Lower Rate:** Switch your outstanding loan to a top-tier bank at attractive rates (~8.40% - 8.65%) to save lakhs of rupees in interest.
2. **Top-Up Liquidity:** Secure an additional top-up loan at home loan rates for business expansion, renovation, or education.
3. **Hassle-Free Processing:** We coordinate foreclosure letters, List of Documents (LOD), and smooth takeover disbursement.

📞 Call **Deepak Verma at +91 9826686170** to calculate your monthly EMI savings!`;
  }

  // General Welcoming & Anshfinance Guidance
  return isHi
    ? `नमस्ते! मैं **Anshfinance AI Sahayak** हूँ — इंदौर में आपके होम लोन का विश्वसनीय सलाहकार।

मैं होम लोन से जुड़ी निम्नलिखित जानकारी में आपकी सहायता कर सकता हूँ:
• 🏠 **होम लोन के प्रकार:** नया घर, प्लॉट + निर्माण, रेनोवेशन या बैलेंस ट्रांसफर
• 📋 **आवश्यक दस्तावेज़:** सैलरीड एवं बिजनेसमैन हेतु संपूर्ण चेकलिस्ट
• 💰 **ब्याज दरें एवं EMI:** वर्तमान बैंक दरें (8.40% से शुरू) और मासिक किश्त का हिसाब
• 📊 **पात्रता व CIBIL स्कोर:** सिबिल स्कोर और इनकम अनुसार लोन राशि का अनुमान
• 🤝 **बैंक विकल्प:** SBI, HDFC, ICICI, Bank of Baroda, LIC HFL आदि में तुलना

आप मुझसे कोई भी सवाल पूछ सकते हैं, जैसे:
* "सैलरीड व्यक्ति को कौन-कौन से कागजात चाहिए?"
* "60 लाख के घर पर कितना लोन मिल सकता है?"
* "क्या खराब CIBIL स्कोर पर लोन संभव है?"

यदि आप सीधे **दीपक वर्मा जी (Anshfinance)** से व्यक्तिगत मार्गदर्शन, फाइल तैयार कराने या होम विजिट चाहते हैं, तो कृपया **9826686170** पर कॉल या WhatsApp करें।`
    : `Hello! I am **Anshfinance AI Sahayak** — your dedicated Home Loan Assistant in Indore.

I can guide you through:
• 🏠 **Home Loan Varieties:** New Home, Plot + Construction, Home Improvement, Balance Transfer
• 📋 **Required Documents:** Comprehensive checklist for Salaried & Self-Employed applicants
• 💰 **Interest Rates & EMI:** Current market rates (starting ~8.40% p.a.) and tenure calculations
• 📊 **Eligibility & CIBIL:** Score requirements and loan amount qualification
• 🤝 **Bank Comparison:** Matching your profile across SBI, HDFC, ICICI, BoB, LIC HFL & NBFCs

Feel free to ask any specific questions! For direct file processing or doorstep consultation in Indore, contact **Deepak Verma at +91 9826686170**.`;
}

startServer();
